
class StablePriorityQueue:
    def __init__(self):
        # ذخیره به صورت تاپل: (priority, entry_count, item)
        self.heap = []
        self.entry_count = 0 

    def push(self, item, priority):
        # entry_count برای تضمین پایداری (FIFO) در اولویت‌های برابر است
        entry = (priority, self.entry_count, item)
        self.heap.append(entry)
        self.entry_count += 1
        self._sift_up(len(self.heap) - 1)

    def pop(self):
        if not self.heap:
            return None # یا هندل کردن طبق خواسته سوال (مثلا چاپ empty)
        
        # ریشه (بیشترین اولویت) را برمی‌داریم
        root_data = self.heap[0]
        
        # آخرین عنصر را جایگزین ریشه می‌کنیم
        last_data = self.heap.pop()
        
        if self.heap:
            self.heap[0] = last_data
            self._sift_down(0)
            
        return root_data[2] # فقط خود آیتم را برمی‌گردانیم

    def _sift_up(self, index):
        parent_index = (index - 1) // 2
        if index > 0 and self._is_higher_priority(index, parent_index):
            self._swap(index, parent_index)
            self._sift_up(parent_index)

    def _sift_down(self, index):
        largest = index
        left_child = 2 * index + 1
        right_child = 2 * index + 2

        if left_child < len(self.heap) and self._is_higher_priority(left_child, largest):
            largest = left_child

        if right_child < len(self.heap) and self._is_higher_priority(right_child, largest):
            largest = right_child

        if largest != index:
            self._swap(index, largest)
            self._sift_down(largest)

    def _is_higher_priority(self, idx1, idx2):
        p1, c1, _ = self.heap[idx1]
        p2, c2, _ = self.heap[idx2]
        
        if p1 != p2:
            return p1 > p2  # Max-Heap: اولویت بالاتر، بهتر است
        return c1 < c2      # Stability: اگر اولویت برابر بود، قدیمی‌تر (Count کمتر) بهتر است

    def _swap(self, i, j):
        self.heap[i], self.heap[j] = self.heap[j], self.heap[i]




def main():
    # خواندن تعداد ها
    try:
        line = input().strip()
        if not line:
            return
        q = int(line)
    except (EOFError, ValueError):
        return

    pq = StablePriorityQueue()

    # پردازش 
    for _ in range(q):
        try:
            command_line = input().strip().split()
            if not command_line:
                continue

            type = command_line[0]

            if type == "push":
                # فرمت: push <priority> <item>
                # مثال: push 10 task_name
                priority = int(command_line[1])
                item = command_line[2]
                pq.push(item, priority)

            elif type == "pop":
                # فرمت: pop
                result = pq.pop()
                if result is None:
                    print("empty")
                else:
                    print(result)

        except (EOFError, IndexError):
            break

if __name__ == "__main__":
    main()


