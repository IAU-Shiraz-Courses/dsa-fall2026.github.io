def median_of_three(arr, left, right):
    mid = (left + right) // 2

    # مرتب‌سازی سه عنصر اول، وسط و آخر برای تعیین میانه
    if arr[left] > arr[mid]:
        arr[left], arr[mid] = arr[mid], arr[left]
    if arr[left] > arr[right]:
        arr[left], arr[right] = arr[right], arr[left]
    if arr[mid] > arr[right]:
        arr[mid], arr[right] = arr[right], arr[mid]

    # عنصر وسط میانه است
    return mid


def partition(arr, left, right):
    pivot = arr[right]
    i = left - 1

    for j in range(left, right):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[right] = arr[right], arr[i + 1]
    return i + 1


def quick_sort(arr, left, right):
    if left >= right:
        return

    pivot_index = median_of_three(arr, left, right)
    arr[pivot_index], arr[right] = arr[right], arr[pivot_index]

    p = partition(arr, left, right)

    quick_sort(arr, left, p - 1)
    quick_sort(arr, p + 1, right)



def main():

    # تبدیل رشته‌ی ورودی به لیست عددی
    arr = list(map(int, input().split()))

    # اجرای الگوریتم مرتب‌سازی
    quick_sort(arr, 0, len(arr) - 1)

    # چاپ نتیجه
    print(arr)


# اجرای مستقیم برنامه
if __name__ == "__main__":
    main()
