class MaxHeap:
    def __init__(self):
        self.data = []

    def push(self, x):
        self.data.append(x)
        i = len(self.data) - 1
        while i > 0:
            p = (i - 1) // 2
            if self.data[p] >= self.data[i]:
                break
            self.data[p], self.data[i] = self.data[i], self.data[p]
            i = p

    def pop(self):
        if not self.data:
            return None
        top = self.data[0]
        last = self.data.pop()
        if self.data:
            self.data[0] = last
            self._heapify(0)
        return top

    def _heapify(self, i):
        n = len(self.data)
        while True:
            l = 2 * i + 1
            r = 2 * i + 2
            largest = i
            if l < n and self.data[l] > self.data[largest]:
                largest = l
            if r < n and self.data[r] > self.data[largest]:
                largest = r
            if largest == i:
                break
            self.data[i], self.data[largest] = self.data[largest], self.data[i]
            i = largest

    def top(self):
        if self.data:
            return self.data[0]
        return None

    def __len__(self):
        return len(self.data)


class MinHeap(MaxHeap):
    def push(self, x):
        super().push(-x)

    def pop(self):
        val = super().pop()
        if val is not None:
            return -val
        return None

    def top(self):
        val = super().top()
        if val is not None:
            return -val
        return None


def sliding_window_median(nums, k):
    maxH = MaxHeap()  # نیمه کوچک (Left)
    minH = MinHeap()  # نیمه بزرگ (Right)
    delayed = {}      # اعداد منتظر حذف
    medians = []
    
    # balance = تعداد معتبر maxH - تعداد معتبر minH
    # هدف: balance همیشه 0 (برای k زوج) یا 1 (برای k فرد) باشد.
    balance = 0 

    def clean(heap):
        """حذف عناصر علامت‌دار از ریشه هیپ"""
        while len(heap) > 0:
            val = heap.top()
            if delayed.get(val, 0) > 0:
                delayed[val] -= 1
                heap.pop()
            else:
                break

    for i, x in enumerate(nums):
        # 1. مدیریت خروج عنصر از پنجره
        if i >= k:
            out_num = nums[i - k]
            delayed[out_num] = delayed.get(out_num, 0) + 1
            
            # تشخیص اینکه عنصر حذف شده متعلق به کدام سمت است.
            # نکته مهم: اینجا نباید clean کنیم، چون ممکن است عنصر حذف شده همان top باشد
            # و ما به مقدار آن برای مرزبندی نیاز داریم.
            # اگر maxH خالی است، قطعا عنصر در minH بوده است.
            if maxH.top() is None:
                balance += 1 # یعنی از minH کم شده (L - (R-1)) -> balance زیاد میشه
            elif out_num <= maxH.top():
                balance -= 1 # از maxH کم شده
            else:
                balance += 1 # از minH کم شده

        # 2. اضافه کردن عنصر جدید
        # اگر maxH خالی است یا x مناسب maxH است
        if maxH.top() is None or x <= maxH.top():
            maxH.push(x)
            balance += 1
        else:
            minH.push(x)
            balance -= 1

        # 3. متعادل‌سازی (Rebalancing)
        # اگر balance > 1 یعنی maxH بیش از حد پر شده -> انتقال به minH
        while balance > 1:
            clean(maxH) # قبل از برداشتن باید تمیز کنیم تا عدد معتبر برداریم
            val = maxH.pop()
            if val is not None:
                minH.push(val)
                balance -= 2
            else:
                # این حالت نباید رخ دهد مگر اینکه balance اشتباه محاسبه شده باشد
                break

        # اگر balance < 0 یعنی minH بیش از حد پر شده -> انتقال به maxH
        while balance < 0:
            clean(minH)
            val = minH.pop()
            if val is not None:
                maxH.push(val)
                balance += 2
            else:
                break
            
        # 4. محاسبه میانه
        if i >= k - 1:
            clean(maxH)
            clean(minH)
            
            if k % 2 == 1:
                # اگر فرد است، میانه در maxH است
                if maxH.top() is not None:
                    medians.append(float(maxH.top()))
                else:
                    # فال‌بک امنیتی، هرچند نباید به اینجا برسد
                    medians.append(0.0) 
            else:
                # اگر زوج است، میانگین دو قله
                top_max = maxH.top()
                top_min = minH.top()
                if top_max is not None and top_min is not None:
                    medians.append((top_max + top_min) / 2.0)
                elif top_max is not None:
                     medians.append(float(top_max))
                elif top_min is not None:
                     medians.append(float(top_min))
                else:
                     medians.append(0.0)

    return medians


def main():
    # خواندن n و k
    try:
        line1 = input().split()
        if not line1: return
        n, k = map(int, line1)

        line2 = input().split()
        if not line2: 
            nums = []
        else:
            nums = list(map(int, line2))
    except ValueError:
        return

    result = sliding_window_median(nums, k)

    for x in result:
        # چاپ بدون اعشار برای اعداد صحیح
        if x == int(x):
            print(int(x))
        else:
            print(x)


if __name__ == "__main__":
    main()
