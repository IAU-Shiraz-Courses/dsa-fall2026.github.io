class Node:
    def __init__(self, value):
        self.value = value
        self.next = None


def quick_sort_linked_list(head):
    if head is None or head.next is None:
        return head

    pivot = head
    current = head.next

    left_dummy = Node(0)
    right_dummy = Node(0)
    left_tail = left_dummy
    right_tail = right_dummy

    while current:
        next_node = current.next
        current.next = None

        if current.value < pivot.value:
            left_tail.next = current
            left_tail = current
        else:
            right_tail.next = current
            right_tail = current

        current = next_node

    left_sorted = quick_sort_linked_list(left_dummy.next)
    right_sorted = quick_sort_linked_list(right_dummy.next)

    pivot.next = right_sorted

    if left_sorted is None:
        return pivot

    tail = left_sorted
    while tail.next:
        tail = tail.next
    tail.next = pivot

    return left_sorted


def main():
    # دریافت ورودی: فقط عدد با فاصله
    numbers = list(map(int, input().split()))

    if not numbers:
        return

    # ساخت Linked List
    head = Node(numbers[0])
    current = head
    for num in numbers[1:]:
        current.next = Node(num)
        current = current.next

    # اجرای Quick Sort
    sorted_head = quick_sort_linked_list(head)

    # چاپ خروجی
    current = sorted_head
    while current:
        print(current.value, end=" ")
        current = current.next


if __name__ == "__main__":
    main()
