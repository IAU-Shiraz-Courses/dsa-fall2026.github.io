# کلاس گره برای درخت قرمز-سیاه
class Node:
    def __init__(self, data):
        self.data = data        # مقدار ذخیره شده در گره
        self.parent = None      # اشاره‌گر به گره پدر
        self.left = None        # اشاره‌گر به فرزند چپ
        self.right = None       # اشاره‌گر به فرزند راست
        self.color = 1          # رنگ گره: 1 = قرمز، 0 = مشکی

# کلاس اصلی درخت قرمز-سیاه
class RedBlackTree:
    def __init__(self):
        # گره نیل (Sentinel) که نقش برگ‌های خالی را دارد و همیشه مشکی است
        self.TNULL = Node(0)
        self.TNULL.color = 0
        # ریشه درخت در ابتدا به گره نیل اشاره می‌کند (درخت خالی)
        self.root = self.TNULL

    def left_rotate(self, x):
        # چرخش چپ روی گره x: فرزند راست x به جای x می‌نشیند
        y = x.right                         # y فرزند راست x است
        x.right = y.left                    # زیردرخت چپ y به فرزند راست x تبدیل می‌شود
        if y.left != self.TNULL:
            y.left.parent = x               # اگر زیردرخت چپ y خالی نبود، پدرش را به x تغییر می‌دهیم
        y.parent = x.parent                 # پدر y را به پدر x تغییر می‌دهیم
        if x.parent is None:
            self.root = y                   # اگر x ریشه بود، y ریشه جدید می‌شود
        elif x == x.parent.left:
            x.parent.left = y               # اگر x فرزند چپ بود، y جای آن را می‌گیرد
        else:
            x.parent.right = y              # اگر x فرزند راست بود، y جای آن را می‌گیرد
        y.left = x                          # x به فرزند چپ y تبدیل می‌شود
        x.parent = y                        # پدر x را به y تغییر می‌دهیم

    def right_rotate(self, x):
        # چرخش راست روی گره x: فرزند چپ x به جای x می‌نشیند
        y = x.left                          # y فرزند چپ x است
        x.left = y.right                    # زیردرخت راست y به فرزند چپ x تبدیل می‌شود
        if y.right != self.TNULL:
            y.right.parent = x              # اگر زیردرخت راست y خالی نبود، پدرش را به x تغییر می‌دهیم
        y.parent = x.parent                 # پدر y را به پدر x تغییر می‌دهیم
        if x.parent is None:
            self.root = y                   # اگر x ریشه بود، y ریشه جدید می‌شود
        elif x == x.parent.right:
            x.parent.right = y              # اگر x فرزند راست بود، y جای آن را می‌گیرد
        else:
            x.parent.left = y              # اگر x فرزند چپ بود، y جای آن را می‌گیرد
        y.right = x                         # x به فرزند راست y تبدیل می‌شود
        x.parent = y                        # پدر x را به y تغییر می‌دهیم

    def insert(self, key):
        # ساخت گره جدید با مقدار key و رنگ قرمز
        node = Node(key)
        node.parent = None
        node.left = self.TNULL
        node.right = self.TNULL
        node.color = 1                      # گره جدید همیشه ابتدا قرمز درج می‌شود

        y = None
        x = self.root

        # پیدا کردن جای مناسب برای درج مثل درخت جستجوی دودویی معمولی
        while x != self.TNULL:
            y = x
            if node.data < x.data:
                x = x.left
            else:
                x = x.right

        # تنظیم پدر گره جدید
        node.parent = y
        if y is None:
            self.root = node                # اگر درخت خالی بود، گره جدید ریشه می‌شود
        elif node.data < y.data:
            y.left = node                   # درج در سمت چپ
        else:
            y.right = node                  # درج در سمت راست

        # اگر گره جدید ریشه شد، رنگش را مشکی کن و تمام
        if node.parent is None:
            node.color = 0
            return

        # اگر پدر بزرگ وجود نداشت نیازی به تصحیح نیست
        if node.parent.parent is None:
            return

        # تصحیح ویژگی‌های درخت قرمز-سیاه پس از درج
        self.insert_fix(node)

    def insert_fix(self, k):
        # تا زمانی که پدر گره k قرمز است (نقض قانون دو گره قرمز متوالی)، تصحیح ادامه دارد
        while k.parent.color == 1:
            if k.parent == k.parent.parent.right:
                # پدر k فرزند راست پدربزرگ است
                u = k.parent.parent.left    # عموی k (فرزند چپ پدربزرگ)
                if u.color == 1:
                    # حالت ۱: عمو قرمز است → فقط رنگ‌ها را عوض می‌کنیم
                    u.color = 0
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    k = k.parent.parent     # مشکل را به بالا منتقل می‌کنیم
                else:
                    # حالت ۲ و ۳: عمو مشکی است → نیاز به چرخش داریم
                    if k == k.parent.left:
                        # حالت ۲: k فرزند چپ است → ابتدا چرخش راست برای تبدیل به حالت ۳
                        k = k.parent
                        self.right_rotate(k)
                    # حالت ۳: k فرزند راست است → چرخش چپ روی پدربزرگ
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    self.left_rotate(k.parent.parent)
            else:
                # پدر k فرزند چپ پدربزرگ است (آینه‌ای از حالت بالا)
                u = k.parent.parent.right   # عموی k (فرزند راست پدربزرگ)
                if u.color == 1:
                    # حالت ۱: عمو قرمز است → فقط رنگ‌ها را عوض می‌کنیم
                    u.color = 0
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    k = k.parent.parent     # مشکل را به بالا منتقل می‌کنیم
                else:
                    # حالت ۲ و ۳: عمو مشکی است → نیاز به چرخش داریم
                    if k == k.parent.right:
                        # حالت ۲: k فرزند راست است → ابتدا چرخش چپ برای تبدیل به حالت ۳
                        k = k.parent
                        self.left_rotate(k)
                    # حالت ۳: k فرزند چپ است → چرخش راست روی پدربزرگ
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    self.right_rotate(k.parent.parent)
            if k == self.root:
                break                       # اگر به ریشه رسیدیم، حلقه را متوقف می‌کنیم
        self.root.color = 0                 # ریشه همیشه باید مشکی باشد

    def get_black_height(self):
        # محاسبه ارتفاع سیاه درخت: تعداد گره‌های مشکی از ریشه تا برگ (بدون احتساب گره‌های نیل)
        # طبق قانون RBT تمام مسیرها ارتفاع سیاه یکسان دارند، پس فقط مسیر چپ را می‌رویم
        if self.root == self.TNULL:
            return 0                        # درخت خالی است

        height = 0
        curr = self.root
        while curr != self.TNULL:
            if curr.color == 0:             # اگر گره مشکی بود، شمارنده را افزایش می‌دهیم
                height += 1
            curr = curr.left
        return height

def solve():
    try:
        q = int(input())                            # خواندن تعداد اعداد
        nums = list(map(int, input().split()))      # خواندن اعداد از ورودی
    except ValueError:
        return                                      # در صورت ورودی نامعتبر، برنامه را متوقف می‌کنیم

    # ساخت درخت قرمز-سیاه و درج یک‌به‌یک اعداد
    bst = RedBlackTree()
    for num in nums:
        bst.insert(num)

    # چاپ خروجی: مقدار ریشه و ارتفاع سیاه
    root_val = bst.root.data
    total_blacks = bst.get_black_height()
    print(f"{root_val} {total_blacks}")

if __name__ == "__main__":
    solve()