import sys

MOD = 10**9 + 7
P_LEFT = 313
P_RIGHT = 317
P_COLOR = 17
P_SIZE = 997

class Node:
    def __init__(self, val):
        self.val = val
        self.color = 1      # 1: Red, 0: Black
        self.left = None
        self.right = None
        self.parent = None
        self.size = 1
        self.hash = 0

class RedBlackTree:
    def __init__(self):
        self.TNULL = Node(0)
        self.TNULL.color = 0
        self.TNULL.size = 0
        self.TNULL.hash = 0
        
        self.root = self.TNULL
        self.nodes_map = {}

    def update(self, node):
        if node == self.TNULL or node is None:
            return
        
        node.size = 1 + node.left.size + node.right.size
        
        h = (node.color * P_COLOR + node.size * P_SIZE) % MOD
        h = (h + node.left.hash * P_LEFT + node.right.hash * P_RIGHT) % MOD
        node.hash = h

    def maintain(self, node):
        while node != self.TNULL and node is not None:
            self.update(node)
            node = node.parent

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.TNULL:
            y.left.parent = x
        y.parent = x.parent
        
        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
            
        y.left = x
        x.parent = y
        
        self.update(x)
        self.update(y)

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.TNULL:
            y.right.parent = x
        y.parent = x.parent
        
        if x.parent is None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
            
        y.right = x
        x.parent = y
        
        self.update(x)
        self.update(y)

    def insert_fixup(self, k):
        while k.parent is not None and k.parent.color == 1:
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u != self.TNULL and u.color == 1:
                    u.color = 0
                    self.update(u)
                    k.parent.color = 0
                    self.update(k.parent)
                    k.parent.parent.color = 1
                    self.update(k.parent.parent)
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = 0
                    self.update(k.parent)
                    k.parent.parent.color = 1
                    self.update(k.parent.parent)
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left
                if u != self.TNULL and u.color == 1:
                    u.color = 0
                    self.update(u)
                    k.parent.color = 0
                    self.update(k.parent)
                    k.parent.parent.color = 1
                    self.update(k.parent.parent)
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = 0
                    self.update(k.parent)
                    k.parent.parent.color = 1
                    self.update(k.parent.parent)
                    self.left_rotate(k.parent.parent)
                    
        self.root.color = 0
        self.update(self.root)

    def insert(self, key):
        node = Node(key)
        node.parent = None
        node.left = self.TNULL
        node.right = self.TNULL
        
        y = None
        x = self.root

        while x != self.TNULL:
            y = x
            if node.val < x.val:
                x = x.left
            else:
                x = x.right

        node.parent = y
        if y is None:
            self.root = node
        elif node.val < y.val:
            y.left = node
        else:
            y.right = node

        self.nodes_map[key] = node

        if node.parent is None:
            node.color = 0
            self.update(node)
            return
            
        if node.parent.parent is None:
            self.update(node)
            self.update(node.parent)
            return

        self.insert_fixup(node)
        self.maintain(node)

    def query(self, x, y):
        u = self.nodes_map.get(x)
        v = self.nodes_map.get(y)
        
        if not u or not v:
            return "NO"
            
        if u.hash == v.hash and u.size == v.size:
            return "YES"
        return "NO"


def solve():
    first_line = sys.stdin.readline()
    if not first_line:
        return
        
    try:
        q = int(first_line.strip())
    except ValueError:
        return

    tree = RedBlackTree()
    results = [] # آرایه‌ای برای ذخیره خروجی‌ها
    
    for _ in range(q):
        line = sys.stdin.readline().split()
        if not line:
            continue
            
        cmd = line[0]
        if cmd == "INSERT":
            val = int(line[1])
            tree.insert(val)
        elif cmd == "CLONE_CHECK":
            x = int(line[1])
            y = int(line[2])
            # به جای چاپ مستقیم، جواب را در آرایه ذخیره می‌کنیم
            results.append(tree.query(x, y))
            
    # چاپ تمام خروجی‌ها به صورت یکجا در انتهای برنامه
    if results:
        print('\n'.join(results))

if __name__ == "__main__":
    solve()
