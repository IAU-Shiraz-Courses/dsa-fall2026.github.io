class Fenwick:
    def __init__(self, n):
        self.n = n
        self.bit = [0] * (n + 1)

    def update(self, idx, val):
        while idx <= self.n:
            self.bit[idx] += val
            idx += idx & -idx

    def query(self, idx):
        s = 0
        while idx > 0:
            s += self.bit[idx]
            idx -= idx & -idx
        return s


def solve():
    n, q = map(int, input().split())
    arr = list(map(int, input().split()))

    bit1 = Fenwick(n)
    bit2 = Fenwick(n)

    def range_add(l, r, v):
        bit1.update(l, v)
        if r + 1 <= n:
            bit1.update(r + 1, -v)

        bit2.update(l, v * (l - 1))
        if r + 1 <= n:
            bit2.update(r + 1, -v * r)

    def prefix_sum(x):
        return x * bit1.query(x) - bit2.query(x)

    def range_sum(l, r):
        return prefix_sum(r) - prefix_sum(l - 1)

    # مقداردهی اولیه
    for i in range(n):
        range_add(i + 1, i + 1, arr[i])

    outputs = []

    for _ in range(q):
        cmd = input().split()

        if cmd[0] == "ADD":
            l = int(cmd[1])
            r = int(cmd[2])
            v = int(cmd[3])
            range_add(l, r, v)

        else:  # SUM
            l = int(cmd[1])
            r = int(cmd[2])
            outputs.append(str(range_sum(l, r)))

    for ans in outputs:
        print(ans)


solve()