class Fenwick2D:
    def __init__(self, n, m):
        self.n = n
        self.m = m
        self.bit = [[0] * (m + 1) for _ in range(n + 1)]

    def update(self, x, y, val):
        i = x
        while i <= self.n:
            j = y
            while j <= self.m:
                self.bit[i][j] += val
                j += j & -j
            i += i & -i

    def query(self, x, y):
        s = 0
        i = x
        while i > 0:
            j = y
            while j > 0:
                s += self.bit[i][j]
                j -= j & -j
            i -= i & -i
        return s

    def rectangle_sum(self, x1, y1, x2, y2):
        return (
            self.query(x2, y2)
            - self.query(x1 - 1, y2)
            - self.query(x2, y1 - 1)
            + self.query(x1 - 1, y1 - 1)
        )


def solve():
    n, m, q = map(int, input().split())

    fenwick = Fenwick2D(n, m)
    outputs = []

    for _ in range(q):
        cmd = input().split()

        if cmd[0] == "ADD":
            x = int(cmd[1])
            y = int(cmd[2])
            v = int(cmd[3])
            fenwick.update(x, y, v)

        else:  # SUM
            x1 = int(cmd[1])
            y1 = int(cmd[2])
            x2 = int(cmd[3])
            y2 = int(cmd[4])
            result = fenwick.rectangle_sum(x1, y1, x2, y2)
            outputs.append(str(result))

    for ans in outputs:
        print(ans)


solve()