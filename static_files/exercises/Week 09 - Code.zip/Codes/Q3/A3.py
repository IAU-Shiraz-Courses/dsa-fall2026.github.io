import sys
sys.setrecursionlimit(10**7)

# ---------- Binary Search ----------
def lower_bound(arr, x):
    l, r = 0, len(arr)
    while l < r:
        mid = (l + r) // 2
        if arr[mid] < x:
            l = mid + 1
        else:
            r = mid
    return l

def upper_bound(arr, x):
    l, r = 0, len(arr)
    while l < r:
        mid = (l + r) // 2
        if arr[mid] <= x:
            l = mid + 1
        else:
            r = mid
    return l


# ---------- Fenwick Tree ----------
class Fenwick:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)

    def update(self, i, delta):
        i += 1
        while i <= self.n:
            self.tree[i] += delta
            i += i & -i

    def query(self, i):
        s = 0
        i += 1
        while i > 0:
            s += self.tree[i]
            i -= i & -i
        return s

    def range_query(self, l, r):
        if l > r:
            return 0
        return self.query(r) - (self.query(l - 1) if l > 0 else 0)


# ---------- Segment Tree ----------
class SegmentTree:
    def __init__(self, arr):
        self.n = len(arr)
        self.arr = arr[:]
        self.tree = [None] * (4 * self.n)
        self.build(1, 0, self.n - 1)

    def build(self, node, l, r):
        if l == r:
            vals = [self.arr[l]]
            ft = Fenwick(1)
            ft.update(0, 1)
            self.tree[node] = {"values": vals, "fenwick": ft}
            return

        mid = (l + r) // 2
        self.build(node*2, l, mid)
        self.build(node*2+1, mid+1, r)

        left_vals = self.tree[node*2]["values"]
        right_vals = self.tree[node*2+1]["values"]

        merged = sorted(left_vals + right_vals)
        ft = Fenwick(len(merged))
        for i in range(len(merged)):
            ft.update(i, 1)

        self.tree[node] = {"values": merged, "fenwick": ft}

    # -------- UPDATE --------
    def update(self, node, l, r, idx, old_val, new_val):
        values = self.tree[node]["values"]
        fenwick = self.tree[node]["fenwick"]

        pos = lower_bound(values, old_val)
        fenwick.update(pos, -1)

        pos = lower_bound(values, new_val)
        fenwick.update(pos, +1)

        if l == r:
            self.arr[idx] = new_val
            return

        mid = (l + r) // 2
        if idx <= mid:
            self.update(node*2, l, mid, idx, old_val, new_val)
        else:
            self.update(node*2+1, mid+1, r, idx, old_val, new_val)

    # -------- COUNT <= x --------
    def count_leq(self, node, l, r, ql, qr, x):
        if qr < l or r < ql:
            return 0
        if ql <= l and r <= qr:
            values = self.tree[node]["values"]
            fenwick = self.tree[node]["fenwick"]
            pos = upper_bound(values, x) - 1
            if pos < 0:
                return 0
            return fenwick.query(pos)

        mid = (l + r) // 2
        return (
            self.count_leq(node*2, l, mid, ql, qr, x) +
            self.count_leq(node*2+1, mid+1, r, ql, qr, x)
        )


# ---------- SOLVE FOR QUERA ----------
def solve():
    data = sys.stdin.read().strip().split()
    ptr = 0

    n = int(data[ptr]); ptr += 1
    q = int(data[ptr]); ptr += 1

    arr = [0]*n
    for i in range(n):
        arr[i] = int(data[ptr]); ptr += 1

    st = SegmentTree(arr)
    out = []

    for _ in range(q):
        cmd = data[ptr]; ptr += 1

        if cmd == "UPDATE":
            i = int(data[ptr]) - 1; ptr += 1
            x = int(data[ptr]); ptr += 1
            old_val = st.arr[i]
            st.update(1, 0, n - 1, i, old_val, x)

        else:  # QUERY
            l = int(data[ptr]) - 1; ptr += 1
            r = int(data[ptr]) - 1; ptr += 1

            inv = 0
            for i in range(l, r+1):
                inv += st.count_leq(1, 0, n-1, i+1, r, st.arr[i] - 1)

            out.append(str(inv))

    sys.stdout.write("\n".join(out))


if __name__ == "__main__":
    solve()
