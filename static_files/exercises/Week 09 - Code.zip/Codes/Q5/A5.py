import sys

# Constants for RBT Colors
RED = 0
BLACK = 1

class RBTNode:
    def __init__(self, key, name, power, pos):
        self.key = key          # Hash of the name
        self.name = name        # Actual string name to handle collisions
        self.power = power
        self.pos = pos
        self.color = RED        # New nodes are always red
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    def __init__(self):
        self.NIL = RBTNode(0, "", 0, 0)
        self.NIL.color = BLACK
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert(self, key, name, power, pos):
        new_node = RBTNode(key, name, power, pos)
        new_node.left = self.NIL
        new_node.right = self.NIL
        
        y = None
        x = self.root
        while x != self.NIL:
            y = x
            if new_node.key < x.key:
                x = x.left
            else:
                x = x.right
                
        new_node.parent = y
        if y == None:
            self.root = new_node
        elif new_node.key < y.key:
            y.left = new_node
        else:
            y.right = new_node
            
        if new_node.parent == None:
            new_node.color = BLACK
            return
        if new_node.parent.parent == None:
            return
            
        self.insert_fixup(new_node)

    def insert_fixup(self, k):
        while k.parent.color == RED:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left # uncle
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right # uncle
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = BLACK

    def search(self, key, name):
        # Search includes checking the actual string 'name' for hash collisions
        curr = self.root
        while curr != self.NIL:
            if key == curr.key and name == curr.name:
                return curr
            elif key < curr.key:
                curr = curr.left
            else:
                curr = curr.right
        return None

    def delete_node(self, key, name):
        node = self.search(key, name)
        if node is None or node == self.NIL:
            return
        
        y = node
        y_original_color = y.color
        if node.left == self.NIL:
            x = node.right
            self.transplant(node, node.right)
        elif node.right == self.NIL:
            x = node.left
            self.transplant(node, node.left)
        else:
            y = self.minimum(node.right)
            y_original_color = y.color
            x = y.right
            if y.parent == node:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = node.right
                y.right.parent = y
            self.transplant(node, y)
            y.left = node.left
            y.left.parent = y
            y.color = node.color
            
        if y_original_color == BLACK:
            self.delete_fixup(x)

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def transplant(self, u, v):
        if u.parent == None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def delete_fixup(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                s = x.parent.right
                if s.color == RED:
                    s.color = BLACK
                    x.parent.color = RED
                    self.left_rotate(x.parent)
                    s = x.parent.right
                if s.left.color == BLACK and s.right.color == BLACK:
                    s.color = RED
                    x = x.parent
                else:
                    if s.right.color == BLACK:
                        s.left.color = BLACK
                        s.color = RED
                        self.right_rotate(s)
                        s = x.parent.right
                    s.color = x.parent.color
                    x.parent.color = BLACK
                    s.right.color = BLACK
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                s = x.parent.left
                if s.color == RED:
                    s.color = BLACK
                    x.parent.color = RED
                    self.right_rotate(x.parent)
                    s = x.parent.left
                if s.right.color == BLACK and s.left.color == BLACK:
                    s.color = RED
                    x = x.parent
                else:
                    if s.left.color == BLACK:
                        s.right.color = BLACK
                        s.color = RED
                        self.left_rotate(s)
                        s = x.parent.left
                    s.color = x.parent.color
                    x.parent.color = BLACK
                    s.left.color = BLACK
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = BLACK


class SegmentTree:
    # (همان پیاده‌سازی قبلی سگمنت تری برای یافتن MAX)
    def __init__(self, size):
        self.size = size
        self.tree = [0] * (4 * size)

    def update(self, node, start, end, idx, val):
        if start == end:
            self.tree[node] = val
            return
        mid = (start + end) // 2
        if start <= idx <= mid:
            self.update(2 * node, start, mid, idx, val)
        else:
            self.update(2 * node + 1, mid + 1, end, idx, val)
        self.tree[node] = max(self.tree[2*node], self.tree[2*node+1])

    def query(self, node, start, end, l, r):
        if r < start or end < l: return 0
        if l <= start and end <= r: return self.tree[node]
        mid = (start + end) // 2
        return max(self.query(2 * node, start, mid, l, r),
                   self.query(2 * node + 1, mid + 1, end, l, r))

# تابع تولید Hash دستی برای کلید RBT
def get_hash(s):
    h = 0
    p = 31
    m = 10**9 + 9
    p_pow = 1
    for char in s:
        h = (h + (ord(char) - 96) * p_pow) % m
        p_pow = (p_pow * p) % m
    return h

def solve():
    input_data = sys.stdin.read().split()
    if not input_data: return
    
    Q = int(input_data[0])
    idx = 1
    MAX_ANVILS = 100005
    
    seg_tree = SegmentTree(MAX_ANVILS)
    stacks = [[] for _ in range(MAX_ANVILS + 1)]
    rbt = RedBlackTree() # استفاده از RBT دستی
    
    output = []
    for _ in range(Q):
        cmd = input_data[idx]
        if cmd == "FORGE":
            name = input_data[idx+1]
            power = int(input_data[idx+2])
            pos = int(input_data[idx+3])
            idx += 4
            
            # دستی هش می‌گیریم و در RBT اینسرت می‌کنیم
            hashed_key = get_hash(name)
            rbt.insert(hashed_key, name, power, pos)
            
            stacks[pos].append((power, name))
            seg_tree.update(1, 1, MAX_ANVILS, pos, power)
            
        elif cmd == "MELT":
            pos = int(input_data[idx+1])
            idx += 2
            if stacks[pos]:
                melted_power, melted_name = stacks[pos].pop()
                
                # سرچ و حذف پیچیده در RBT دستی
                hashed_key = get_hash(melted_name)
                rbt.delete_node(hashed_key, melted_name)
                
                new_top_power = stacks[pos][-1][0] if stacks[pos] else 0
                seg_tree.update(1, 1, MAX_ANVILS, pos, new_top_power)
                
        elif cmd == "INSPECT":
            name = input_data[idx+1]
            idx += 2
            
            # سرچ دستی در RBT با استفاده از هش و رفع تصادم (Collision)
            hashed_key = get_hash(name)
            node = rbt.search(hashed_key, name)
            if node:
                output.append(f"{node.power} {node.pos}")
            else:
                output.append("NOT_FOUND")
                
        elif cmd == "MAX_TOP":
            L, R = int(input_data[idx+1]), int(input_data[idx+2])
            idx += 3
            output.append(str(seg_tree.query(1, 1, MAX_ANVILS, L, R)))

    print('\n'.join(output))

if __name__ == '__main__':
    solve()
