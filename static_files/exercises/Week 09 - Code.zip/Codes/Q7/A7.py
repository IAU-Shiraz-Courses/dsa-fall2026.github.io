def solve():
    try:
        n = int(input())
    except ValueError:
        return

    # اگر درخت خالی است، بی‌شک معتبر است
    if n == 0:
        print("YES")
        return

    # ذخیره درخت در دیکشنری برای دسترسی سریع
    # nodes[id] = {'color': 'R'/'B', 'left': int, 'right': int}
    nodes = {}

    for _ in range(n):
        parts = input().split()
        u_id = int(parts[0])
        color = parts[1]
        left = int(parts[2])
        right = int(parts[3])
        nodes[u_id] = {'color': color, 'left': left, 'right': right}

    root_id = 1

    # قانون ۱: ریشه باید سیاه باشد
    if nodes[root_id]['color'] == 'R':
        print("NO")
        return

    # بررسی درخت با پیمایش تکراری (بدون بازگشت) با استفاده از پشته
    # هر آیتم پشته: (u_id, مرحله) و دیکشنری ارتفاع سیاه محاسبه‌شده
    bh = {}         # bh[u_id] = ارتفاع سیاه زیردرخت گره u_id
    stack = [(root_id, False)]  # (گره, آیا فرزندان پردازش شده‌اند)
    valid = True

    while stack and valid:
        u_id, processed = stack.pop()

        # گره نیل
        if u_id == 0:
            bh[0] = 1       # نیل سیاه حساب می‌شود
            continue

        node = nodes[u_id]

        if not processed:
            # بار اول: ابتدا فرزندان را به پشته اضافه کن، بعد خودت را
            stack.append((u_id, True))
            stack.append((node['right'], False))
            stack.append((node['left'], False))
        else:
            # بار دوم: فرزندان پردازش شده‌اند، حالا این گره را بررسی کن

            # قانون ۲: دو گره قرمز پشت سر هم نباشند
            if node['color'] == 'R':
                left_id = node['left']
                right_id = node['right']
                if left_id != 0 and nodes[left_id]['color'] == 'R':
                    valid = False
                    break
                if right_id != 0 and nodes[right_id]['color'] == 'R':
                    valid = False
                    break

            bh_left = bh.get(node['left'], 1)
            bh_right = bh.get(node['right'], 1)

            # قانون ۳: ارتفاع سیاه زیردرخت چپ و راست باید برابر باشد
            if bh_left != bh_right:
                valid = False
                break

            # محاسبه ارتفاع سیاه این گره و ذخیره آن
            bh[u_id] = bh_left + (1 if node['color'] == 'B' else 0)

    if valid:
        print("YES")
    else:
        print("NO")

if __name__ == "__main__":
    solve()