import sys

# Constants for Red-Black Tree
RED = True
BLACK = False

# ==========================================
# 1. Doubly Linked List Node (For Groups)
# ==========================================
class ListNode:
    def __init__(self, id, val):
        self.id = id
        self.val = val
        self.prev = None
        self.next = None

# ==========================================
# 2. Fenwick Tree (Binary Indexed Tree)
# ==========================================
class FenwickTree:
    def __init__(self, size):
        self.tree = [0] * (size + 1)

    def add(self, i, delta):
        while i < len(self.tree):
            self.tree[i] += delta
            i += i & (-i)

    def query(self, i):
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= i & (-i)
        return s

# ==========================================
# 3. Dynamic Segment Tree (For Max Val & Hash over ID ranges)
# ==========================================
class SegNode:
    def __init__(self):
        self.max_val = -float('inf')
        self.hash_val = 0
        self.left = None
        self.right = None

class DynamicSegmentTree:
    def __init__(self, min_id, max_id):
        self.root = SegNode()
        self.min_id = min_id
        self.max_id = max_id
        self.BASE = 31
        self.MOD = 10**9 + 7

    def _update(self, node, l, r, idx, val, hash_v, is_delete=False):
        if l == r:
            if is_delete:
                node.max_val = -float('inf')
                node.hash_val = 0
            else:
                node.max_val = val
                node.hash_val = hash_v
            return

        mid = (l + r) // 2
        if idx <= mid:
            if not node.left: node.left = SegNode()
            self._update(node.left, l, mid, idx, val, hash_v, is_delete)
        else:
            if not node.right: node.right = SegNode()
            self._update(node.right, mid + 1, r, idx, val, hash_v, is_delete)

        left_max = node.left.max_val if node.left else -float('inf')
        right_max = node.right.max_val if node.right else -float('inf')
        node.max_val = max(left_max, right_max)

    def update(self, idx, val, hash_v, is_delete=False):
        self._update(self.root, self.min_id, self.max_id, idx, val, hash_v, is_delete)

    def _query_max(self, node, l, r, ql, qr):
        if not node or ql > r or qr < l:
            return -float('inf')
        if ql <= l and r <= qr:
            return node.max_val
        mid = (l + r) // 2
        return max(self._query_max(node.left, l, mid, ql, qr),
                   self._query_max(node.right, mid + 1, r, ql, qr))

    def query_max(self, ql, qr):
        return self._query_max(self.root, self.min_id, self.max_id, ql, qr)

# ==========================================
# 4. Pure Red-Black Tree Implementation
# ==========================================
class RBNode:
    def __init__(self, key, val, group, list_node):
        self.key = key
        self.val = val
        self.group = group
        self.list_node = list_node
        self.color = RED
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(0, 0, 0, None)
        self.NIL.color = BLACK
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert(self, key, val, group, list_node):
        node = RBNode(key, val, group, list_node)
        node.left = self.NIL
        node.right = self.NIL
        
        y = None
        x = self.root
        while x != self.NIL:
            y = x
            if node.key < x.key: x = x.left
            else: x = x.right

        node.parent = y
        if y == None: self.root = node
        elif node.key < y.key: y.left = node
        else: y.right = node

        if node.parent == None:
            node.color = BLACK
            return node
        if node.parent.parent == None:
            return node

        self.insert_fixup(node)
        return node

    def insert_fixup(self, k):
        while k.parent.color == RED:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right
                if u.color == RED:
                    u.color = BLACK
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)
            if k == self.root: break
        self.root.color = BLACK

    def search(self, key):
        curr = self.root
        while curr != self.NIL and key != curr.key:
            if key < curr.key: curr = curr.left
            else: curr = curr.right
        return curr

    def transplant(self, u, v):
        if u.parent == None: self.root = v
        elif u == u.parent.left: u.parent.left = v
        else: u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, z):
        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == BLACK:
            self.delete_fixup(x)

    def delete_fixup(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self.left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == BLACK and w.right.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.right.color == BLACK:
                        w.left.color = BLACK
                        w.color = RED
                        self.right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.right.color = BLACK
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == RED:
                    w.color = BLACK
                    x.parent.color = RED
                    self.right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == BLACK and w.left.color == BLACK:
                    w.color = RED
                    x = x.parent
                else:
                    if w.left.color == BLACK:
                        w.right.color = BLACK
                        w.color = RED
                        self.left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color
                    x.parent.color = BLACK
                    w.left.color = BLACK
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = BLACK

# ==========================================
# 5. Main System Integration
# ==========================================
def string_hash(s):
    h = 0
    for char in s:
        h = (h * 31 + ord(char)) % (10**9 + 7)
    return h

def solve():
    input_data = sys.stdin.read().split()
    if not input_data: return
    
    Q = int(input_data[0])
    idx = 1
    
    MAX_ID = 10**9
    MAX_GROUP = 10**5
    
    rb_tree = RedBlackTree()
    seg_tree = DynamicSegmentTree(1, MAX_ID)
    fenwick = FenwickTree(MAX_GROUP)
    
    # Linked lists for each group (head and tail pointers)
    group_heads = {i: None for i in range(1, MAX_GROUP + 1)}
    group_tails = {i: None for i in range(1, MAX_GROUP + 1)}
    
    results = []
    
    for _ in range(Q):
        cmd = input_data[idx]
        if cmd == "ADD":
            id_val = int(input_data[idx+1])
            val = int(input_data[idx+2])
            group = int(input_data[idx+3])
            s = input_data[idx+4]
            idx += 5
            
            # 1. Hashing
            h_val = string_hash(s)
            
            # 2. Linked List Logic
            new_list_node = ListNode(id_val, val)
            if group_tails[group] is None:
                group_heads[group] = group_tails[group] = new_list_node
            else:
                new_list_node.prev = group_tails[group]
                group_tails[group].next = new_list_node
                group_tails[group] = new_list_node
                
            # 3. RB Tree Integration
            rb_tree.insert(id_val, val, group, new_list_node)
            
            # 4. Segment Tree
            seg_tree.update(id_val, val, h_val)
            
            # 5. Fenwick Tree
            fenwick.add(group, val)
            
        elif cmd == "REMOVE":
            id_val = int(input_data[idx+1])
            idx += 2
            
            node = rb_tree.search(id_val)
            if node != rb_tree.NIL:
                # Remove from Fenwick
                fenwick.add(node.group, -node.val)
                
                # Remove from Segment Tree
                seg_tree.update(id_val, 0, 0, is_delete=True)
                
                # Remove from Linked List
                lnode = node.list_node
                if lnode.prev: lnode.prev.next = lnode.next
                else: group_heads[node.group] = lnode.next
                if lnode.next: lnode.next.prev = lnode.prev
                else: group_tails[node.group] = lnode.prev
                
                # Remove from RB Tree
                rb_tree.delete(node)
                
        elif cmd == "MAX_VAL":
            L = int(input_data[idx+1])
            R = int(input_data[idx+2])
            idx += 3
            res = seg_tree.query_max(L, R)
            results.append(str(res if res != -float('inf') else "NONE"))
            
        elif cmd == "GROUP_SUM":
            G = int(input_data[idx+1])
            idx += 2
            results.append(str(fenwick.query(G)))
            
        elif cmd == "RECENT_IN_GROUP":
            G = int(input_data[idx+1])
            idx += 2
            if group_tails[G]:
                results.append(str(group_tails[G].val))
            else:
                results.append("EMPTY")

    if results:
        sys.stdout.write('\n'.join(results) + '\n')

if __name__ == '__main__':
    solve()
