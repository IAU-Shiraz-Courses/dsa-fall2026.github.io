class DynamicOrderTable:
    def __init__(self, initial_size=5):
        self.size = initial_size
        self.count = 0
        self.table = [[] for _ in range(self.size)]

    def _hash(self, key: str) -> int:
        return sum(ord(c) for c in key) % self.size

    def _rehash(self):
        old_table = self.table
        self.size *= 2
        self.table = [[] for _ in range(self.size)]
        self.count = 0
        for chain in old_table:
            for key in chain:
                self._insert_without_rehash(key)

    def _insert_without_rehash(self, key: str):
        index = self._hash(key)
        self.table[index].append(key)
        self.count += 1

    def insert(self, key: str):
        if self.count >= self.size:
            self._rehash()
        self._insert_without_rehash(key)

    def display(self):
        for i in range(self.size):
            print(f"خانه {i}: {self.table[i]}")

# -------------------------
# برنامه اصلی
# -------------------------
raw_input = input().strip()
if raw_input == "":
    orders = []
else:
    orders = [o.strip() for o in raw_input.split(",")]

order_table = DynamicOrderTable(initial_size=5)
for order in orders:
    if order:
        order_table.insert(order)

order_table.display()
