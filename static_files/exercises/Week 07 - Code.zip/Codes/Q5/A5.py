class DynamicHashTable:
    def __init__(self, initial_size=5):
        # اندازه اولیه جدول هش
        self.size = initial_size

        # تعداد کل عناصر ذخیره‌شده
        self.count = 0

        # ایجاد جدول هش با لیست‌های زنجیره‌ای
        self.table = [[] for _ in range(self.size)]

    def _hash(self, key: str) -> int:
        """
        تابع هش برای رشته‌ها:
        مجموع کدهای ASCII کاراکترها
        و گرفتن باقیمانده نسبت به اندازه جدول
        """
        return sum(ord(c) for c in key) % self.size

    def _rehash(self):
        """
        دو برابر کردن اندازه جدول و
        بازدرج تمام عناصر قبلی
        """
        old_table = self.table
        self.size *= 2
        self.table = [[] for _ in range(self.size)]
        self.count = 0

        for chain in old_table:
            for key in chain:
                self._insert_without_rehash(key)

    def _insert_without_rehash(self, key: str):
        index = self._hash(key)
        self.table[index].append(key)
        self.count += 1

    def insert(self, key: str):
        if self.count >= self.size:
            self._rehash()
        self._insert_without_rehash(key)

    def display(self):
        for i in range(self.size):
            print(f"خانه {i}: {self.table[i]}")


raw_input = input().strip()

if raw_input == "":
    tickets = []
else:
    tickets = [t.strip() for t in raw_input.split(",")]

hash_table = DynamicHashTable(initial_size=5)

for ticket in tickets:
    if ticket:
        hash_table.insert(ticket)

hash_table.display()
