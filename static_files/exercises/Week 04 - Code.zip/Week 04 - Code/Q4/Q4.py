class TreeNode:
    """
    کلاس گره درخت جستجوی دودویی (BST)

    هر گره کد یک ایستگاه مترو و اشاره‌گر به فرزند چپ و راست
    خود را نگه می‌دارد.
    """

    def __init__(self, value):
        """
        سازنده کلاس TreeNode - ایجاد یک گره جدید برای یک ایستگاه

        ورودی:
            value (int): کد ایستگاه
        """
        self.value = value  # کد ایستگاه (مقدار گره)
        self.left = None    # اشاره‌گر به فرزند چپ
        self.right = None   # اشاره‌گر به فرزند راست


def insert_value(root, value):
    """
    درج یک کد ایستگاه جدید در BST به‌صورت تکراری (بدون بازگشت)

    اگر مقدار از قبل در درخت وجود داشته باشد، هیچ تغییری
    اعمال نمی‌شود.

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت (یا None اگر خالی باشد)
        value (int): کدی که باید درج شود

    خروجی:
        TreeNode: ریشه‌ی درخت پس از درج
    """
    if root is None:
        return TreeNode(value)

    current_node = root
    while True:
        if value == current_node.value:
            return root
        elif value < current_node.value:
            if current_node.left is None:
                current_node.left = TreeNode(value)
                return root
            current_node = current_node.left
        else:
            if current_node.right is None:
                current_node.right = TreeNode(value)
                return root
            current_node = current_node.right


def find_value(root, value):
    """
    جستجوی یک کد ایستگاه در BST به‌صورت تکراری

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        value (int): کدی که باید جستجو شود

    خروجی:
        bool: True اگر کد در درخت وجود داشته باشد، در غیر این صورت False
    """
    current_node = root
    while current_node is not None:
        if value == current_node.value:
            return True
        elif value < current_node.value:
            current_node = current_node.left
        else:
            current_node = current_node.right
    return False


def find_lca(root, first_station, second_station):
    """
    پیدا کردن نزدیک‌ترین جد مشترک (LCA) دو ایستگاه در BST به‌صورت تکراری

    از ویژگی BST استفاده می‌شود تا بدون پیمایش کل درخت، مسیر
    مشترک دو ایستگاه پیدا شود. این تابع فرض می‌کند هر دو ایستگاه
    از قبل در درخت وجود دارند.

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        first_station (int): کد ایستگاه اول
        second_station (int): کد ایستگاه دوم

    خروجی:
        int: کد ایستگاهی که نزدیک‌ترین جد مشترک است
    """
    current_node = root
    while True:
        if first_station < current_node.value and second_station < current_node.value:
            # هر دو ایستگاه در زیردرخت چپ قرار دارند
            current_node = current_node.left
        elif first_station > current_node.value and second_station > current_node.value:
            # هر دو ایستگاه در زیردرخت راست قرار دارند
            current_node = current_node.right
        else:
            # مسیر دو ایستگاه از اینجا جدا می‌شود، یا یکی از آن‌ها همین گره است
            return current_node.value


# دریافت تعداد ایستگاه‌ها
station_count = int(input())

# دریافت کد ایستگاه‌ها و ساخت BST به همان ترتیب ورودی
station_codes = list(map(int, input().split()))

metro_root = None
for code in station_codes:
    metro_root = insert_value(metro_root, code)

# دریافت تعداد درخواست‌ها
query_count = int(input())

# خواندن کامل تمام درخواست‌ها قبل از هرگونه چاپ خروجی
all_queries = []
for _ in range(query_count):
    all_queries.append(tuple(map(int, input().split())))

# پردازش هر درخواست و جمع‌آوری خروجی‌ها بدون چاپ فوری
output_lines = []
for station_a, station_b in all_queries:
    first_exists = find_value(metro_root, station_a)
    second_exists = find_value(metro_root, station_b)

    if not first_exists or not second_exists:
        output_lines.append("NOT FOUND")
    else:
        lca_value = find_lca(metro_root, station_a, station_b)
        output_lines.append(str(lca_value))

# چاپ تمام خروجی‌ها در پایان برنامه، پس از پردازش کامل ورودی
print("\n".join(output_lines))