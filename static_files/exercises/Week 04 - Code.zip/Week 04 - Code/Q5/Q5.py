class TreeNode:
    """
    کلاس گره درخت جستجوی دودویی پیشرفته (Augmented BST)

    هر گره برای یک قیمت یکتا ساخته می‌شود و اطلاعات زیر را نگه می‌دارد:
    price: قیمت سفارش
    count: تعداد سفارش‌هایی که دقیقاً همین قیمت را دارند
    size: تعداد کل سفارش‌ها در این گره و زیردرخت‌های آن
    sum: مجموع قیمت تمام سفارش‌ها در این گره و زیردرخت‌های آن
    left/right/parent: اشاره‌گر به فرزند چپ، فرزند راست و پدر
    """

    def __init__(self, price):
        """
        سازنده کلاس TreeNode - ایجاد یک گره جدید برای یک قیمت جدید

        ورودی:
            price (int): قیمت سفارش
        """
        self.price = price   # قیمت سفارش (کلید مرتب‌سازی BST)
        self.count = 1       # تعداد سفارش‌های همین قیمت
        self.left = None     # اشاره‌گر به فرزند چپ
        self.right = None    # اشاره‌گر به فرزند راست
        self.parent = None   # اشاره‌گر به گره پدر
        self.size = 1        # تعداد کل سفارش‌ها در این گره و زیردرخت‌ها
        self.sum = price     # مجموع قیمت‌ها در این گره و زیردرخت‌ها


def update_node_statistics(node):
    """
    به‌روزرسانی مقادیر size و sum یک گره بر اساس فرزندانش

    ورودی:
        node (TreeNode): گره‌ای که باید آمار آن به‌روزرسانی شود
    """
    left_size = node.left.size if node.left is not None else 0
    right_size = node.right.size if node.right is not None else 0
    left_sum = node.left.sum if node.left is not None else 0
    right_sum = node.right.sum if node.right is not None else 0

    node.size = node.count + left_size + right_size
    node.sum = node.price * node.count + left_sum + right_sum


def update_ancestors(node):
    """
    به‌روزرسانی size و sum یک گره و تمام اجداد آن تا ریشه، به‌صورت تکراری

    این تابع پس از هر تغییر ساختاری یا تغییر count فراخوانی می‌شود
    تا اطلاعات آماری کل مسیر تا ریشه صحیح باقی بماند.

    ورودی:
        node (TreeNode): گره‌ای که تغییر از آنجا شروع شده (یا None)
    """
    current_node = node
    while current_node is not None:
        update_node_statistics(current_node)
        current_node = current_node.parent


def insert_order(root, price):
    """
    ثبت یک سفارش جدید با قیمت price در درخت، به‌صورت تکراری

    اگر قیمت از قبل وجود داشته باشد، فقط count همان گره افزایش
    می‌یابد؛ در غیر این صورت گره جدیدی ساخته می‌شود.

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت (یا None اگر خالی باشد)
        price (int): قیمت سفارش جدید

    خروجی:
        TreeNode: ریشه‌ی درخت پس از درج
    """
    # اگر درخت خالی است، گره جدید خودش ریشه می‌شود
    if root is None:
        return TreeNode(price)

    current_node = root
    while True:
        if price == current_node.price:
            # قیمت تکراری است؛ فقط شمارنده افزایش می‌یابد
            current_node.count += 1
            update_ancestors(current_node)
            return root
        elif price < current_node.price:
            if current_node.left is None:
                new_node = TreeNode(price)
                new_node.parent = current_node
                current_node.left = new_node
                update_ancestors(new_node)
                return root
            current_node = current_node.left
        else:
            if current_node.right is None:
                new_node = TreeNode(price)
                new_node.parent = current_node
                current_node.right = new_node
                update_ancestors(new_node)
                return root
            current_node = current_node.right


def find_min_node(node):
    """
    پیدا کردن گره با کوچک‌ترین قیمت در یک زیردرخت (تکراری)

    ورودی:
        node (TreeNode): ریشه‌ی زیردرختی که باید کمینه‌ی آن پیدا شود

    خروجی:
        TreeNode: گره‌ای با کوچک‌ترین قیمت در آن زیردرخت
    """
    while node.left is not None:
        node = node.left
    return node


def replace_node_in_parent(root, old_node, new_node):
    """
    جایگزین کردن old_node با new_node در گره پدرش (یا در ریشه‌ی درخت)

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت
        old_node (TreeNode): گره‌ای که باید از درخت جدا شود
        new_node (TreeNode): گره‌ای که باید جایگزین آن شود (یا None)

    خروجی:
        TreeNode: ریشه‌ی جدید درخت
    """
    if old_node.parent is None:
        # گره حذف‌شده خود ریشه‌ی درخت بود
        root = new_node
    else:
        if old_node.parent.left is old_node:
            old_node.parent.left = new_node
        else:
            old_node.parent.right = new_node

    if new_node is not None:
        new_node.parent = old_node.parent

    return root


def delete_order(root, price):
    """
    حذف یک سفارش با قیمت price از درخت، به‌صورت تکراری

    اگر count گره بزرگ‌تر از ۱ باشد، فقط یک واحد کاهش می‌یابد.
    در غیر این صورت خود گره طبق هر سه حالت ممکن (بدون فرزند،
    یک فرزند، دو فرزند) از درخت حذف می‌شود. اگر قیمت موردنظر
    در درخت وجود نداشته باشد، هیچ تغییری اعمال نمی‌شود.

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت
        price (int): قیمتی که باید حذف شود

    خروجی:
        TreeNode: ریشه‌ی جدید درخت پس از حذف
    """
    # پیدا کردن گره هدف به‌صورت تکراری
    target_node = root
    while target_node is not None and target_node.price != price:
        if price < target_node.price:
            target_node = target_node.left
        else:
            target_node = target_node.right

    # اگر قیمت در درخت وجود نداشت، بدون تغییر برمی‌گردیم
    if target_node is None:
        return root

    if target_node.count > 1:
        # فقط یک سفارش از این قیمت حذف می‌شود، گره باقی می‌ماند
        target_node.count -= 1
        update_ancestors(target_node)
        return root

    # count == 1 است؛ باید خود گره از درخت حذف شود
    if target_node.left is not None and target_node.right is not None:
        # حالت سوم: گره دو فرزند دارد
        # کوچک‌ترین قیمت زیردرخت راست، جانشین گره حذف‌شده می‌شود
        successor_node = find_min_node(target_node.right)

        # انتقال قیمت و شمارنده‌ی جانشین به گره هدف
        target_node.price = successor_node.price
        target_node.count = successor_node.count

        # جانشین حداکثر یک فرزند (راست) دارد، پس طبق حالت ۱ یا ۲ حذف می‌شود
        successor_parent = successor_node.parent
        root = replace_node_in_parent(root, successor_node, successor_node.right)
        update_ancestors(successor_parent)

    elif target_node.left is not None:
        # حالت دوم: گره فقط فرزند چپ دارد
        target_parent = target_node.parent
        root = replace_node_in_parent(root, target_node, target_node.left)
        update_ancestors(target_parent)

    elif target_node.right is not None:
        # حالت دوم: گره فقط فرزند راست دارد
        target_parent = target_node.parent
        root = replace_node_in_parent(root, target_node, target_node.right)
        update_ancestors(target_parent)

    else:
        # حالت اول: گره هیچ فرزندی ندارد (برگ است)
        target_parent = target_node.parent
        root = replace_node_in_parent(root, target_node, None)
        update_ancestors(target_parent)

    return root


def get_sum_up_to(root, limit_price):
    """
    محاسبه‌ی مجموع قیمت تمام سفارش‌هایی که قیمتشان کوچک‌تر یا مساوی
    limit_price است، به‌صورت تکراری و فقط با پیمودن یک مسیر از ریشه

    اگر قیمت گره فعلی از limit_price بیشتر نباشد، خود گره و تمام
    زیردرخت چپ آن در جمع وارد می‌شوند (با استفاده از sum زیردرخت چپ)
    و فقط به سمت راست ادامه می‌دهیم؛ در غیر این صورت گره و زیردرخت
    راستش خارج از محدوده‌اند و فقط به سمت چپ می‌رویم.

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        limit_price (int): بیشینه‌ی قیمت موردنظر

    خروجی:
        int: مجموع قیمت سفارش‌های با قیمت <= limit_price
    """
    total_sum = 0
    current_node = root

    while current_node is not None:
        if current_node.price <= limit_price:
            left_sum = current_node.left.sum if current_node.left is not None else 0
            total_sum += current_node.price * current_node.count + left_sum
            current_node = current_node.right
        else:
            current_node = current_node.left

    return total_sum


def get_range_sum(root, low_price, high_price):
    """
    محاسبه‌ی مجموع قیمت سفارش‌هایی که در بازه‌ی بسته‌ی
    [low_price, high_price] قرار دارند، در زمان O(h)

    مجموع بازه برابر است با:
    (مجموع قیمت‌های <= high_price) منهای (مجموع قیمت‌های <= low_price - 1)

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        low_price (int): کران پایین بازه
        high_price (int): کران بالای بازه

    خروجی:
        int: مجموع قیمت سفارش‌های داخل بازه (اگر چیزی نبود، صفر)
    """
    if low_price > high_price:
        return 0
    return get_sum_up_to(root, high_price) - get_sum_up_to(root, low_price - 1)


def get_kth_largest_price(root, k):
    """
    پیدا کردن قیمت k اُمین سفارش گران‌تر، به‌صورت تکراری

    از مقدار size زیردرخت راست برای تصمیم‌گیری در هر مرحله
    استفاده می‌شود تا نیازی به پیمایش کل درخت نباشد.

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        k (int): رتبه‌ی موردنظر (از گران‌ترین به ارزان‌ترین)

    خروجی:
        int یا None: قیمت k اُمین سفارش گران‌تر، یا None اگر
                     تعداد سفارش‌ها کمتر از k باشد
    """
    current_node = root
    remaining_rank = k

    while current_node is not None:
        right_size = current_node.right.size if current_node.right is not None else 0

        if remaining_rank <= right_size:
            # پاسخ در زیردرخت راست (سفارش‌های گران‌تر) قرار دارد
            current_node = current_node.right
        elif remaining_rank <= right_size + current_node.count:
            # پاسخ دقیقاً در محدوده‌ی همین قیمت قرار می‌گیرد
            return current_node.price
        else:
            # باید از تعداد رتبه‌های بررسی‌نشده کم کرده و به چپ برویم
            remaining_rank -= (right_size + current_node.count)
            current_node = current_node.left

    # تعداد سفارش‌ها کمتر از k بوده است
    return None


def get_top_k_sum(root, k):
    """
    محاسبه‌ی مجموع قیمت گران‌ترین k سفارش، به‌صورت تکراری

    مشابه get_kth_largest_price عمل می‌کند، اما به‌جای پیدا کردن
    فقط یک قیمت، مجموع تمام k سفارش گران‌تر را جمع می‌کند.

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        k (int): تعداد سفارش‌های گران‌تری که باید در نظر گرفته شوند

    خروجی:
        int یا None: مجموع قیمت k سفارش گران‌تر، یا None اگر
                     تعداد سفارش‌ها کمتر از k باشد
    """
    current_node = root
    remaining_rank = k
    total_sum = 0

    while current_node is not None and remaining_rank > 0:
        right_size = current_node.right.size if current_node.right is not None else 0
        right_sum = current_node.right.sum if current_node.right is not None else 0

        if remaining_rank <= right_size:
            # هنوز همه‌ی k سفارش موردنیاز در زیردرخت راست قرار دارند
            current_node = current_node.right
        else:
            # کل زیردرخت راست را در مجموع وارد می‌کنیم
            if right_size > 0:
                total_sum += right_sum
                remaining_rank -= right_size

            # سهم همین گره را تا حد نیاز اضافه می‌کنیم
            taken_count = min(remaining_rank, current_node.count)
            total_sum += taken_count * current_node.price
            remaining_rank -= taken_count

            current_node = current_node.left

    if remaining_rank > 0:
        # تعداد سفارش‌ها کمتر از k بوده است
        return None

    return total_sum


# دریافت تعداد عملیات‌ها
operation_count = int(input())

# ریشه‌ی درخت؛ در ابتدا درخت خالی است
exchange_root = None

# لیستی برای جمع‌آوری خروجی‌ها (برای چاپ کارآمدتر در انتها)
output_lines = []

# پردازش هر عملیات به ترتیب
for _ in range(operation_count):
    operation_parts = input().split()
    operation_type = operation_parts[0]

    if operation_type == "1":
        # ثبت سفارش
        order_price = int(operation_parts[1])
        exchange_root = insert_order(exchange_root, order_price)

    elif operation_type == "2":
        # حذف سفارش
        order_price = int(operation_parts[1])
        exchange_root = delete_order(exchange_root, order_price)

    elif operation_type == "3":
        # مجموع قیمت سفارش‌های داخل یک بازه
        low_bound = int(operation_parts[1])
        high_bound = int(operation_parts[2])
        range_total = get_range_sum(exchange_root, low_bound, high_bound)
        output_lines.append(str(range_total))

    elif operation_type == "4":
        # قیمت k اُمین سفارش گران‌تر
        rank_k = int(operation_parts[1])
        kth_price = get_kth_largest_price(exchange_root, rank_k)
        if kth_price is not None:
            output_lines.append(str(kth_price))

    elif operation_type == "5":
        # میانگین قیمت گران‌ترین k سفارش
        rank_k = int(operation_parts[1])
        top_k_sum = get_top_k_sum(exchange_root, rank_k)
        if top_k_sum is not None:
            output_lines.append(str(top_k_sum // rank_k))

# چاپ تمام خروجی‌ها در پایان برنامه
print("\n".join(output_lines))