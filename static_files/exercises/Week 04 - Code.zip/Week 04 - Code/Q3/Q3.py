class TreeNode:
    """
    کلاس گره درخت جستجوی دودویی (BST)

    هر گره یک مقدار (کد بسته) و اشاره‌گر به فرزند چپ، فرزند راست
    و پدر خود را نگه می‌دارد. اشاره‌گر پدر برای حذف کارآمد و
    بدون نیاز به بازگشت استفاده می‌شود.
    """

    def __init__(self, value, parent):
        """
        سازنده کلاس TreeNode - ایجاد یک گره جدید برای یک کد بسته

        ورودی:
            value (int): کد بسته
            parent (TreeNode): اشاره‌گر به گره پدر (یا None اگر ریشه باشد)
        """
        self.value = value    # کد بسته (مقدار گره)
        self.parent = parent  # اشاره‌گر به گره پدر
        self.left = None      # اشاره‌گر به فرزند چپ
        self.right = None     # اشاره‌گر به فرزند راست


def insert_value(root, value):
    """
    درج یک مقدار جدید در BST به‌صورت تکراری (بدون بازگشت)

    اگر مقدار از قبل در درخت وجود داشته باشد، هیچ تغییری
    اعمال نمی‌شود چون مقادیر تکراری در این مسئله مجاز نیستند.

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت (یا None اگر درخت خالی باشد)
        value (int): مقداری که باید درج شود

    خروجی:
        TreeNode: ریشه‌ی درخت پس از درج (در صورت خالی بودن درخت تغییر می‌کند)
    """
    # اگر درخت خالی است، گره جدید خودش ریشه می‌شود
    if root is None:
        return TreeNode(value, None)

    # حرکت تکراری در درخت تا رسیدن به جای درست درج
    current_node = root
    while True:
        if value == current_node.value:
            # مقدار تکراری است، هیچ تغییری اعمال نمی‌شود
            return root
        elif value < current_node.value:
            # باید به سمت زیردرخت چپ برویم
            if current_node.left is None:
                current_node.left = TreeNode(value, current_node)
                return root
            current_node = current_node.left
        else:
            # باید به سمت زیردرخت راست برویم
            if current_node.right is None:
                current_node.right = TreeNode(value, current_node)
                return root
            current_node = current_node.right


def find_value(root, value):
    """
    جستجوی یک مقدار در BST به‌صورت تکراری

    ورودی:
        root (TreeNode): ریشه‌ی درخت
        value (int): مقداری که باید جستجو شود

    خروجی:
        bool: True اگر مقدار پیدا شود، در غیر این صورت False
    """
    current_node = root

    # حرکت در درخت تا پیدا شدن مقدار یا رسیدن به گره خالی
    while current_node is not None:
        if value == current_node.value:
            return True
        elif value < current_node.value:
            current_node = current_node.left
        else:
            current_node = current_node.right

    # مقدار در درخت پیدا نشد
    return False


def find_min_node(node):
    """
    پیدا کردن کوچک‌ترین گره در یک زیردرخت (تکراری)

    با حرکت مداوم به سمت فرزند چپ، به کوچک‌ترین مقدار می‌رسیم؛
    زیرا در BST تمام مقادیر زیردرخت چپ از گره فعلی کوچک‌ترند.

    ورودی:
        node (TreeNode): ریشه‌ی زیردرختی که باید کمینه‌ی آن پیدا شود

    خروجی:
        TreeNode: گره‌ای با کوچک‌ترین مقدار در آن زیردرخت
    """
    while node.left is not None:
        node = node.left
    return node


def replace_node_in_parent(root, old_node, new_node):
    """
    جایگزین کردن old_node با new_node در گره پدرش (یا در ریشه‌ی درخت)

    این تابع برای پیاده‌سازی هر سه حالت حذف استفاده می‌شود:
    کافی است فرزند جایگزین (new_node می‌تواند None هم باشد) را
    به‌جای گره حذف‌شده به پدرش متصل کنیم.

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت
        old_node (TreeNode): گره‌ای که باید از درخت جدا شود
        new_node (TreeNode): گره‌ای که باید جایگزین آن شود (یا None)

    خروجی:
        TreeNode: ریشه‌ی جدید درخت (در صورت حذف ریشه، تغییر می‌کند)
    """
    if old_node.parent is None:
        # گره حذف‌شده خود ریشه‌ی درخت بود
        root = new_node
    else:
        # اتصال پدر گره حذف‌شده به گره جایگزین
        if old_node.parent.left is old_node:
            old_node.parent.left = new_node
        else:
            old_node.parent.right = new_node

    # به‌روزرسانی اشاره‌گر پدر برای گره جایگزین (در صورت وجود)
    if new_node is not None:
        new_node.parent = old_node.parent

    return root


def delete_value(root, value):
    """
    حذف یک مقدار از BST با مدیریت هر سه حالت ممکن، به‌صورت تکراری

    حالت ۱: گره بدون فرزند (برگ) - به سادگی حذف می‌شود
    حالت ۲: گره با یک فرزند - همان فرزند جای گره را می‌گیرد
    حالت ۳: گره با دو فرزند - کوچک‌ترین مقدار زیردرخت راست
             جانشین آن می‌شود و سپس آن جانشین از جای اصلی‌اش حذف می‌شود

    اگر مقدار موردنظر در درخت وجود نداشته باشد، هیچ تغییری
    اعمال نمی‌شود.

    ورودی:
        root (TreeNode): ریشه‌ی فعلی درخت
        value (int): مقداری که باید حذف شود

    خروجی:
        TreeNode: ریشه‌ی جدید درخت پس از حذف
    """
    # پیدا کردن گره هدف به‌صورت تکراری
    target_node = root
    while target_node is not None and target_node.value != value:
        if value < target_node.value:
            target_node = target_node.left
        else:
            target_node = target_node.right

    # اگر مقدار در درخت وجود نداشت، بدون تغییر برمی‌گردیم
    if target_node is None:
        return root

    if target_node.left is not None and target_node.right is not None:
        # حالت سوم: گره دو فرزند دارد
        # کوچک‌ترین مقدار زیردرخت راست را به‌عنوان جانشین پیدا می‌کنیم
        successor_node = find_min_node(target_node.right)

        # مقدار جانشین را جایگزین مقدار گره هدف می‌کنیم
        target_node.value = successor_node.value

        # جانشین حداکثر یک فرزند (راست) دارد، پس طبق حالت ۱ یا ۲ حذف می‌شود
        root = replace_node_in_parent(root, successor_node, successor_node.right)

    elif target_node.left is not None:
        # حالت دوم: گره فقط فرزند چپ دارد
        root = replace_node_in_parent(root, target_node, target_node.left)

    elif target_node.right is not None:
        # حالت دوم: گره فقط فرزند راست دارد
        root = replace_node_in_parent(root, target_node, target_node.right)

    else:
        # حالت اول: گره هیچ فرزندی ندارد (برگ است)
        root = replace_node_in_parent(root, target_node, None)

    return root


def get_inorder_values(root):
    """
    پیمایش Inorder درخت به‌صورت تکراری با استفاده از یک پشته

    طبق ویژگی BST، پیمایش Inorder مقادیر را به ترتیب صعودی
    برمی‌گرداند. از روش تکراری استفاده شده تا در درخت‌های
    نامتعادل و بزرگ، خطای عمق بازگشت رخ ندهد.

    ورودی:
        root (TreeNode): ریشه‌ی درخت

    خروجی:
        list: لیست مقادیر گره‌ها به ترتیب صعودی
    """
    sorted_values = []
    traversal_stack = []
    current_node = root

    # پیمایش تکراری: تا رسیدن به کوچک‌ترین گره سمت چپ می‌رویم،
    # سپس گره را پردازش کرده و به سمت راست حرکت می‌کنیم
    while traversal_stack or current_node is not None:
        while current_node is not None:
            traversal_stack.append(current_node)
            current_node = current_node.left

        current_node = traversal_stack.pop()
        sorted_values.append(current_node.value)
        current_node = current_node.right

    return sorted_values


# دریافت تعداد عملیات‌ها
operation_count = int(input())

# ریشه‌ی درخت؛ در ابتدا درخت خالی است
bst_root = None

# لیستی برای جمع‌آوری تمام دستورات ورودی، تا کل ورودی قبل از
# تولید هر خروجی خوانده شود
all_commands = []
for _ in range(operation_count):
    all_commands.append(input().split())

# لیستی برای جمع‌آوری خروجی‌ها؛ چاپ نهایی پس از پردازش کامل انجام می‌شود
output_lines = []

# پردازش هر عملیات به ترتیب و اجرای دستور مربوطه
for command_parts in all_commands:
    command_name = command_parts[0]

    if command_name == "ADD":
        package_code = int(command_parts[1])
        bst_root = insert_value(bst_root, package_code)

    elif command_name == "REMOVE":
        package_code = int(command_parts[1])
        bst_root = delete_value(bst_root, package_code)

    elif command_name == "FIND":
        package_code = int(command_parts[1])
        if find_value(bst_root, package_code):
            output_lines.append("YES")
        else:
            output_lines.append("NO")

    elif command_name == "PRINT":
        sorted_codes = get_inorder_values(bst_root)
        output_lines.append(" ".join(map(str, sorted_codes)))

# چاپ تمام خروجی‌ها در پایان برنامه، پس از پردازش کامل ورودی
print("\n".join(output_lines))