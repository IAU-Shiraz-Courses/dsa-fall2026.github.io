class TreeNode:
    """
    کلاس گره درخت دودویی

    هر گره نمایانگر یک اتاق در موزه است و شماره‌ی آن اتاق
    (room_number) و اشاره‌گر به فرزند چپ و راست را نگه می‌دارد
    """

    def __init__(self, room_number):
        """
        سازنده کلاس TreeNode - ایجاد یک گره جدید برای یک اتاق

        ورودی:
            room_number (int): شماره‌ی یکتای اتاق
        """
        self.room_number = room_number  # شماره اتاق (مقدار گره)
        self.left = None                # اشاره‌گر به فرزند چپ
        self.right = None               # اشاره‌گر به فرزند راست


def build_tree_from_preorder_and_inorder(preorder_list, inorder_list):
    """
    بازسازی درخت دودویی موزه با استفاده از دو ترتیب پیمایش
    Preorder و Inorder

    ورودی:
        preorder_list (list): لیست شماره اتاق‌ها به ترتیب Preorder
        inorder_list (list): لیست شماره اتاق‌ها به ترتیب Inorder

    خروجی:
        TreeNode: ریشه‌ی درخت بازسازی‌شده (یا None اگر لیست خالی باشد)
    """
    # اگر لیست ورودی خالی باشد، درختی برای ساختن وجود ندارد
    if not preorder_list:
        return None

    # این پیاده‌سازی تکراری با یک پشته و فقط یک پیمایش روی preorder،
    # درخت را در زمان O(n) می‌سازد (بدون جست‌وجوی خطی برای پیدا کردن ریشه‌ها)

    # ریشه‌ی کل درخت، همیشه اولین عنصر preorder است
    root = TreeNode(preorder_list[0])

    # از یک پشته برای ساخت تکراری درخت استفاده می‌کنیم تا از خطای
    # عمق بازگشت در درخت‌های نامتعادل (شبیه زنجیره) جلوگیری شود
    node_stack = [root]

    # اشاره‌گر به موقعیت فعلی در لیست inorder
    inorder_pointer = 0

    total_rooms = len(preorder_list)

    # پیمایش preorder از دومین عنصر به بعد و اتصال هر گره به جای درست خود
    for i in range(1, total_rooms):
        new_node = TreeNode(preorder_list[i])

        # این متغیر آخرین گره‌ای را نگه می‌دارد که زیردرخت چپش کامل شده
        last_completed_node = None

        # اگر مقدار بالای پشته با مقدار جاری در inorder برابر باشد،
        # یعنی زیردرخت چپ آن گره تمام شده و باید از پشته خارج شود
        while node_stack and node_stack[-1].room_number == inorder_list[inorder_pointer]:
            last_completed_node = node_stack.pop()
            inorder_pointer += 1

        if last_completed_node is not None:
            # گره جدید فرزند راست آخرین گره خارج‌شده از پشته است
            last_completed_node.right = new_node
        else:
            # در غیر این صورت، گره جدید فرزند چپ گره بالای پشته است
            node_stack[-1].left = new_node

        # گره جدید را به پشته اضافه می‌کنیم تا فرزندانش پردازش شوند
        node_stack.append(new_node)

    return root


def get_postorder_traversal(root):
    """
    محاسبه‌ی پیمایش Postorder درخت به‌صورت تکراری (بدون بازگشت)

    ورودی:
        root (TreeNode): ریشه‌ی درخت

    خروجی:
        list: لیست شماره اتاق‌ها به ترتیب Postorder
    """
    # اگر درخت خالی باشد، پیمایش خالی برمی‌گردانیم
    if root is None:
        return []

    # این لیست ابتدا ترتیب "ریشه -> راست -> چپ" را می‌سازد
    reverse_postorder = []
    traversal_stack = [root]

    while traversal_stack:
        current_node = traversal_stack.pop()
        reverse_postorder.append(current_node.room_number)

        # ابتدا فرزند چپ و سپس فرزند راست را در پشته قرار می‌دهیم
        # تا فرزند راست زودتر از پشته خارج و پردازش شود
        if current_node.left is not None:
            traversal_stack.append(current_node.left)
        if current_node.right is not None:
            traversal_stack.append(current_node.right)

    # معکوس کردن نتیجه، ترتیب صحیح Postorder را می‌دهد
    reverse_postorder.reverse()
    return reverse_postorder


# دریافت تعداد اتاق‌های موزه
room_count = int(input())

# دریافت ترتیب Preorder اتاق‌ها
preorder_rooms = list(map(int, input().split()))

# دریافت ترتیب Inorder اتاق‌ها
inorder_rooms = list(map(int, input().split()))

# بازسازی درخت موزه از روی دو ترتیب داده‌شده
museum_root = build_tree_from_preorder_and_inorder(preorder_rooms, inorder_rooms)

# محاسبه‌ی پیمایش Postorder درخت بازسازی‌شده
postorder_rooms = get_postorder_traversal(museum_root)

# چاپ خروجی نهایی با یک فاصله بین شماره‌ها
print(" ".join(map(str, postorder_rooms)))