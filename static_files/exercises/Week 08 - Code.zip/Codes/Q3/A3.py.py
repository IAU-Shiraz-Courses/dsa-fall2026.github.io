from collections import deque
import sys

def solve():
    """
    حل مسئله پیدا کردن کوتاه‌ترین مسیر در گراف بدون وزن
    با استفاده از الگوریتم BFS (پیمایش سطحی)
    """
    # خواندن تمام ورودی به صورت یکجا برای کارایی بیشتر
    data = sys.stdin.read().strip().split()
    if not data:
        return
    
    idx = 0
    # خواندن تعداد رأس‌ها (n) و تعداد یال‌ها (m)
    n = int(data[idx]); idx += 1
    m = int(data[idx]); idx += 1
    
    # ساختن لیست مجاورت (گراف بدون جهت)
    graph = [[] for _ in range(n)]
    
    # خواندن m یال
    for _ in range(m):
        u = int(data[idx]); idx += 1
        v = int(data[idx]); idx += 1
        # اضافه کردن یال در هر دو جهت (گراف بدون جهت)
        graph[u].append(v)
        graph[v].append(u)
    
    # خواندن مبدأ (s) و مقصد (t)
    s = int(data[idx]); idx += 1
    t = int(data[idx]); idx += 1
    
    # اگر مبدأ و مقصد یکی هستند، فاصله صفر است
    if s == t:
        print(0)
        return
    
    # آرایه فاصله: مقدار -1 به معنای دیده نشده است
    dist = [-1] * n
    dist[s] = 0  # فاصله مبدأ تا خودش صفر است
    
    # صف BFS
    queue = deque([s])
    
    # پیمایش سطحی گراف
    while queue:
        current = queue.popleft()
        
        # بررسی همه همسایه‌های رأس فعلی
        for neighbor in graph[current]:
            # اگر همسایه قبلاً دیده نشده باشد
            if dist[neighbor] == -1:
                # فاصله همسایه = فاصله رأس فعلی + 1
                dist[neighbor] = dist[current] + 1
                
                # اگر به مقصد رسیدیم، می‌توانیم زودتر خارج شویم
                if neighbor == t:
                    print(dist[neighbor])
                    return
                
                # اضافه کردن همسایه به انتهای صف
                queue.append(neighbor)
    
    # اگر BFS تمام شد و به مقصد نرسیدیم، یعنی مسیری وجود ندارد
    print("NO POWER")


if __name__ == "__main__":
    solve()