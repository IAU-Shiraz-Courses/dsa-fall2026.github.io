import math

# پیاده‌سازی گراف با ماتریس وزن‌ها (مشابه فایل آموزشی)
class Graph:
    def __init__(self, n):
        # ماتریس وزن‌ها: اگر یالی نباشد = inf
        self.n = n
        self.E = [[math.inf for _ in range(n)] for _ in range(n)]
        # یال خودی = 0
        for i in range(n):
            self.E[i][i] = 0

# تابع دایکسترا با روش O(V^2) مطابق جزوه
def dijkstra(G, s):
    n = G.n

    # d[i] = فاصله از s تا i
    d = [math.inf] * n
    d[s] = 0

    # این آرایه مشخص می‌کند رأس i وارد مجموعه S شده یا نه
    S = [False] * n

    for _ in range(n):
        # پیدا کردن کوچک‌ترین d بین رأس‌های خارج از S
        u = -1
        min_val = math.inf
        for i in range(n):
            if not S[i] and d[i] < min_val:
                min_val = d[i]
                u = i

        if u == -1:
            break

        S[u] = True

        # relax یال‌های خروجی از u
        for v in range(n):
            if not S[v] and G.E[u][v] != math.inf:
                # اگر d[u] + وزن(u,v) بهتر باشد، به‌روزرسانی کن
                if d[u] + G.E[u][v] < d[v]:
                    d[v] = d[u] + G.E[u][v]

    return d

# تابع محاسبه وزن مؤثر یک یال بر اساس R و C
def effective_cost(w, R, C):
    if w <= R:
        return w
    # تعداد قطعات لازم
    parts = (w + R - 1) // R   # معادل ceil(w/R)
    stops = parts - 1
    return w + stops * C

def main():
    # دریافت ورودی
    n, m, R, C = map(int, input().split())
    S, T = map(int, input().split())

    G = Graph(n)

    # خواندن یال‌ها و تبدیل وزن
    for _ in range(m):
        u, v, w = map(int, input().split())
        cost = effective_cost(w, R, C)
        G.E[u][v] = min(G.E[u][v], cost)  # اگر چند یال بود، کمترین را نگه داریم

    # اجرای دایکسترا
    dist = dijkstra(G, S)

    # چاپ نتیجه
    if dist[T] == math.inf:
        print(-1)
    else:
        print(dist[T])

# اجرای برنامه
if __name__ == "__main__":
    main()
