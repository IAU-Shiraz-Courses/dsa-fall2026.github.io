# تابع محاسبه MinHash برای یک بردار با یک جایگشت مشخص
def minhash_with_permutation(vector, permutation):
    """
    این تابع MinHash یک مقاله را تحت یک جایگشت محاسبه می‌کند.
    ابتدا بردار را طبق جایگشت بررسی می‌کنیم و
    اولین مکانی که مقدار 1 دارد را برمی‌گردانیم.
    اگر هیچ 1 وجود نداشت مقدار -1 برگردانده می‌شود.
    """
    
    for idx in range(len(permutation)):
        # اندیس واقعی کلمه در بردار اصلی
        original_index = permutation[idx]
        
        # اگر مقاله این کلمه را داشته باشد
        if vector[original_index] == 1:
            return idx
    
    # اگر مقاله هیچ کلمه‌ای نداشت
    return -1


# تابع محاسبه شباهت تقریبی Jaccard از روی امضاهای MinHash
def approx_jaccard(sig1, sig2):
    matches = 0
    
    for i in range(len(sig1)):
        if sig1[i] == sig2[i]:
            matches += 1
    
    return matches / len(sig1)


# خواندن n, m, k
n, m, k = map(int, input().split())

# خواندن بردار مقاله‌ها
data = []
for _ in range(n):
    row = list(map(int, input().split()))
    data.append(row)

# خواندن جایگشت‌ها
permutations = []
for _ in range(k):
    perm = list(map(int, input().split()))
    permutations.append(perm)

# مقاله مورد نظر
q = int(input())

# محاسبه امضاهای MinHash
signatures = []

for i in range(n):
    sig = []
    
    for perm in permutations:
        value = minhash_with_permutation(data[i], perm)
        sig.append(value)
    
    signatures.append(sig)

# پیدا کردن شبیه‌ترین مقاله
best_article = -1
best_similarity = -1

for i in range(n):
    
    # خود مقاله بررسی نشود
    if i == q:
        continue
    
    sim = approx_jaccard(signatures[q], signatures[i])
    
    if sim > best_similarity:
        best_similarity = sim
        best_article = i
    elif sim == best_similarity and i < best_article:
        best_article = i

# چاپ نتیجه
print(best_article)
