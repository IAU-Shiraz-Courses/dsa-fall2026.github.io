# فیلدهای مجاز برای مرتب‌سازی و اندیس هر کدام در تاپل رکورد
FIELDS = {'name': 0, 'score': 1, 'age': 2}

# حداکثر طول مجاز برای نام
MAX_NAME_LEN = 20


class Roster:
    """
    نگهدارنده‌ی لیست رکوردها به همراه عملیات مرتب‌سازی پایدار

    هر رکورد یک تاپل به شکل (name, score, age) است و ترتیب فعلی لیست
    نتیجه‌ی آخرین دستور مرتب‌سازی است
    """

    def __init__(self):
        self.records = []

    def find_index(self, name):
        """
        پیدا کردن اندیس رکوردی با نام داده‌شده؛ در صورت نبودن None برمی‌گرداند
        """
        for i in range(len(self.records)):
            if self.records[i][0] == name:
                return i
        return None

    def add(self, name, score, age):
        """
        افزودن یک رکورد جدید به انتهای لیست
        """
        if self.find_index(name) is not None:
            print("Name already exists")
            return

        self.records.append((name, score, age))
        print("Added " + name)

    def remove(self, name):
        """
        حذف رکورد با نام داده‌شده
        """
        idx = self.find_index(name)
        if idx is None:
            print("Record not found")
            return

        self.records.pop(idx)
        print("Removed " + name)

    def stable_sort(self, field, ascending):
        """
        مرتب‌سازی پایدار لیست رکوردها بر اساس یک فیلد

        پیاده‌سازی با مرتب‌سازی درجی انجام شده است که ذاتاً پایدار است؛
        چون عنصر جاری فقط از روی عناصری رد می‌شود که اکیداً از آن بزرگ‌ترند
        (یا در حالت نزولی، اکیداً کوچک‌ترند) و هرگز از روی عنصر هم‌کلید خود
        عبور نمی‌کند
        """
        pos = FIELDS[field]
        a = self.records

        for k in range(1, len(a)):
            item = a[k]
            i = k

            # شرط مقایسه بر اساس صعودی یا نزولی بودن تعیین می‌شود
            while i > 0 and (
                (a[i - 1][pos] > item[pos]) if ascending else (a[i - 1][pos] < item[pos])
            ):
                a[i] = a[i - 1]
                i -= 1

            a[i] = item

        print("Sorted by " + field + (" asc" if ascending else " desc"))

    def show(self):
        """
        چاپ رکوردها به ترتیب فعلی لیست
        """
        if not self.records:
            print("No records")
            return

        print("Records:")
        for name, score, age in self.records:
            print("%s %d %d" % (name, score, age))


def valid_name(name):
    """
    بررسی معتبر بودن نام: فقط حروف انگلیسی، ارقام و زیرخط، با طول ۱ تا ۲۰
    """
    if not (1 <= len(name) <= MAX_NAME_LEN):
        return False

    for ch in name:
        if not (ch.isascii() and (ch.isalnum() or ch == '_')):
            return False
    return True


def parse_int(token, low, high):
    """
    تبدیل توکن به عدد صحیح در بازه‌ی مشخص؛ در صورت نامعتبر بودن None برمی‌گرداند
    """
    try:
        value = int(token)
    except ValueError:
        return None

    if not (low <= value <= high):
        return None
    return value


def main():
    # خواندن کل ورودی بدون نیاز به هیچ کتابخانه‌ای
    text = open(0).read()
    lines = text.split('\n')

    # اگر ورودی با خط جدید تمام شده باشد، آخرین عنصر یک رشته‌ی خالی ساختگی است
    if lines and lines[-1] == '':
        lines.pop()

    roster = Roster()

    for line in lines:
        parts = line.split()

        # سطر خالی هم یک دستور نامعتبر است
        if not parts:
            print("invalid input")
            continue

        command = parts[0]

        if command == "exit":
            # دستور خروج نباید پارامتر اضافه داشته باشد
            if len(parts) != 1:
                print("invalid input")
                continue
            break

        elif command == "add":
            if len(parts) != 4:
                print("invalid input")
                continue

            name = parts[1]
            score = parse_int(parts[2], 0, 100)
            age = parse_int(parts[3], 1, 120)

            if not valid_name(name) or score is None or age is None:
                print("invalid input")
                continue

            roster.add(name, score, age)

        elif command == "remove":
            if len(parts) != 2 or not valid_name(parts[1]):
                print("invalid input")
                continue

            roster.remove(parts[1])

        elif command in ("sort", "rsort"):
            if len(parts) != 2 or parts[1] not in FIELDS:
                print("invalid input")
                continue

            roster.stable_sort(parts[1], command == "sort")

        elif command == "show":
            if len(parts) != 1:
                print("invalid input")
                continue

            roster.show()

        else:
            print("invalid input")


main()
