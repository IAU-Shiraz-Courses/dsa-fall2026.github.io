def insertion_sort_with_trace(a):
    """
    مرتب‌سازی درجی همراه با گزارش وضعیت آرایه بعد از هر مرحله‌ی درج

    ورودی:
        a (list): آرایه‌ی ورودی (در جا مرتب می‌شود)

    خروجی:
        (list, int): لیست وضعیت‌های آرایه بعد از هر مرحله و تعداد کل انتقال‌ها
    """
    n = len(a)
    trace = []
    shifts = 0

    # شروع از دومین عنصر (اندیس ۱) تا انتهای آرایه
    for k in range(1, n):
        # عنصری که قرار است در جای صحیح خود درج شود
        item = a[k]

        # i موقعیت فعلی item در بخش مرتب‌شده است
        i = k

        # عناصر اکیداً بزرگ‌تر یک خانه به راست منتقل می‌شوند تا جا باز شود
        while i > 0 and a[i - 1] > item:
            a[i] = a[i - 1]
            shifts += 1
            i -= 1

        # درج item در موقعیت صحیح خود
        a[i] = item

        # ثبت یک کپی از وضعیت آرایه پس از این مرحله‌ی درج
        trace.append(list(a))

    return trace, shifts


def main():
    # خواندن کل ورودی بدون نیاز به هیچ کتابخانه‌ای
    data = open(0).read().split()

    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]

    trace, shifts = insertion_sort_with_trace(a)

    out = []
    for state in trace:
        out.append(' '.join(map(str, state)))
    out.append(str(shifts))

    print('\n'.join(out))


main()
