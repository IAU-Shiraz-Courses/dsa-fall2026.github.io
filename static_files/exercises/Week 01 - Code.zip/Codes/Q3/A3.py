def bubble_sort_with_stats(a):
    """
    شبیه‌سازی دقیق فرایند توصیف‌شده در صورت سوال

    ورودی:
        a (list): آرایه‌ی ورودی (در جا مرتب می‌شود)

    خروجی:
        (int, int): تعداد کل جابه‌جایی‌ها و تعداد دورهای اجراشده
    """
    n = len(a)
    swaps = 0
    passes = 0

    while True:
        # هر بار که وارد یک دور می‌شویم آن را می‌شماریم، حتی اگر خالی از جابه‌جایی باشد
        passes += 1
        swapped = False

        # پیمایش از انتهای آرایه به سمت ابتدا
        for j in range(n - 1, 0, -1):
            if a[j] < a[j - 1]:
                a[j], a[j - 1] = a[j - 1], a[j]
                swaps += 1
                swapped = True

        # شرط توقف: یک دور کامل بدون هیچ جابه‌جایی
        if not swapped:
            break

    return swaps, passes


def main():
    # خواندن کل ورودی بدون نیاز به هیچ کتابخانه‌ای
    data = open(0).read().split()

    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]

    swaps, passes = bubble_sort_with_stats(a)

    print(swaps)
    print(passes)
    print(' '.join(map(str, a)))


main()
