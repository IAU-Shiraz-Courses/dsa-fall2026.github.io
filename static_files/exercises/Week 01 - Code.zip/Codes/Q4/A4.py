def digit_count(x):
    """
    تعداد ارقام یک عدد صحیح نامنفی در مبنای ۱۰

    عدد صفر یک رقم دارد
    """
    if x == 0:
        return 1

    d = 0
    while x > 0:
        d += 1
        x //= 10
    return d


def radix_sort_with_trace(a):
    """
    مرتب‌سازی مبنایی غیربازگشتی (LSD) با گزارش وضعیت آرایه بعد از هر دور

    ورودی:
        a (list): آرایه‌ای از اعداد صحیح نامنفی

    خروجی:
        list: لیست وضعیت‌های آرایه بعد از هر دور مرتب‌سازی بر اساس یک رقم
    """
    # تعداد دورها برابر تعداد ارقام بزرگ‌ترین عدد آرایه است
    passes = digit_count(max(a))

    trace = []
    radix = 1  # شروع از رقم یکان

    for _ in range(passes):
        # ۱۰ سطل برای ارقام ۰ تا ۹
        buckets = [[] for _ in range(10)]

        # مرحله‌ی پخش کردن: هر عدد را بر اساس رقم فعلی در سطل خودش می‌گذاریم
        # چون آرایه را از چپ به راست پیمایش می‌کنیم و به انتهای سطل اضافه می‌کنیم،
        # ترتیب نسبی عناصر هم‌رقم حفظ می‌شود؛ یعنی این توزیع پایدار است
        for x in a:
            bucket_number = (x // radix) % 10
            buckets[bucket_number].append(x)

        # مرحله‌ی جمع‌آوری: سطل‌ها را به ترتیب شماره پشت سر هم می‌چینیم
        a = []
        for i in range(10):
            a += buckets[i]

        # ثبت وضعیت آرایه پس از این دور
        trace.append(list(a))

        # رفتن به سراغ رقم بعدی (دهگان، صدگان، ...)
        radix *= 10

    return trace


def main():
    # خواندن کل ورودی بدون نیاز به هیچ کتابخانه‌ای
    data = open(0).read().split()

    n = int(data[0])
    a = [int(x) for x in data[1:1 + n]]

    out = []
    for state in radix_sort_with_trace(a):
        out.append(' '.join(map(str, state)))

    print('\n'.join(out))


main()
