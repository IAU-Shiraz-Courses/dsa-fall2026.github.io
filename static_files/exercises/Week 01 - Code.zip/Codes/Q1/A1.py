def counting_sort(a, m):
    """
    مرتب‌سازی شمارشی روی آرایه‌ای از اعداد صحیح نامنفی

    ورودی:
        a (list): آرایه‌ی ورودی
        m (int): بزرگ‌ترین مقدار ممکن در آرایه

    خروجی:
        (list, list): آرایه‌ی مرتب‌شده و آرایه‌ی شمارنده Count
    """
    # آرایه‌ی کمکی Count با اندازه m+1 و مقدار اولیه‌ی صفر
    count = [0] * (m + 1)

    # یک دور پیمایش آرایه‌ی اصلی و شمردن تعداد تکرار هر عدد
    for x in a:
        count[x] += 1

    # ساخت آرایه‌ی مرتب‌شده از روی آرایه‌ی Count
    sorted_a = []
    for i in range(m + 1):
        # عدد i را به تعداد تکرارش به خروجی اضافه می‌کنیم
        if count[i]:
            sorted_a += [i] * count[i]

    return sorted_a, count


def most_frequent(count):
    """
    پیدا کردن پرتکرارترین عدد از روی آرایه‌ی Count

    در صورت تساوی تعداد تکرار، کوچک‌ترین عدد برگردانده می‌شود
    """
    best_value = 0
    best_count = -1
    for i in range(len(count)):
        # شرط «بزرگ‌تر اکید» تضمین می‌کند در حالت تساوی، عدد کوچک‌تر انتخاب شود
        if count[i] > best_count:
            best_count = count[i]
            best_value = i
    return best_value


def main():
    # خواندن کل ورودی بدون نیاز به هیچ کتابخانه‌ای
    # عدد صفر یعنی توصیف‌گر فایل ورودی استاندارد
    data = open(0).read().split()

    n = int(data[0])
    scores = [int(x) for x in data[1:1 + n]]

    # بیشترین نمره‌ی ممکن طبق صورت سوال ۱۰۰ است
    sorted_scores, count = counting_sort(scores, 100)

    print(' '.join(map(str, sorted_scores)))
    print(most_frequent(count))


main()
