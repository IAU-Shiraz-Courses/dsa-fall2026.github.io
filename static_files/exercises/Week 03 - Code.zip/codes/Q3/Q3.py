class MyQueue:
    def __init__(self):
        self.stack1 = []
        self.stack2 = []

    def enqueue(self, x):
        # عنصر جدید ابتدا وارد پشته اول می‌شود
        self.stack1.append(x)

    def _transfer(self):
        # فقط زمانی که پشته دوم خالی باشد،
        # عناصر پشته اول به پشته دوم منتقل می‌شوند
        if not self.stack2:
            while self.stack1:
                self.stack2.append(self.stack1.pop())

    def dequeue(self):
        # در صورت نیاز عناصر را منتقل می‌کنیم
        self._transfer()

        # اگر هر دو پشته خالی باشند، صف خالی است
        if not self.stack2:
            return None

        # قدیمی‌ترین عنصر صف حذف و برگردانده می‌شود
        return self.stack2.pop()

    def front(self):
        # در صورت نیاز عناصر را منتقل می‌کنیم
        self._transfer()

        # اگر صف خالی باشد
        if not self.stack2:
            return None

        # مشاهده اولین عنصر بدون حذف آن
        return self.stack2[-1]


def main():
    queue = MyQueue()

    while True:
        try:
            command_line = input().strip()

            if not command_line:
                print("invalid input")
                continue

            parts = command_line.split()
            command = parts[0]

            # enqueue x
            if command == "enqueue":

                if len(parts) != 2:
                    print("invalid input")
                    continue

                try:
                    value = int(parts[1])
                    queue.enqueue(value)

                except ValueError:
                    print("invalid input")

            # dequeue
            elif command == "dequeue":

                if len(parts) != 1:
                    print("invalid input")
                    continue

                result = queue.dequeue()

                if result is None:
                    print("Queue is empty")
                else:
                    print(result)

            # front
            elif command == "front":

                if len(parts) != 1:
                    print("invalid input")
                    continue

                result = queue.front()

                if result is None:
                    print("Queue is empty")
                else:
                    print(result)

            # exit
            elif command == "exit":

                if len(parts) != 1:
                    print("invalid input")
                    continue

                break

            # دستور ناشناخته
            else:
                print("invalid input")

        except EOFError:
            break


if __name__ == "__main__":
    main()