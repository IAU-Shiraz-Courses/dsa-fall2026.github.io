class SinglyLinkedListNode:
    def __init__(self, node_data):
        self.data = node_data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None


def insertNodeAtTail(head, data):
    # ساخت گره جدید
    new_node = SinglyLinkedListNode(data)

    # اگر لیست خالی باشد، گره جدید head می‌شود
    if head is None:
        return new_node

    # شروع پیمایش از ابتدای لیست
    current = head

    # حرکت تا آخرین گره
    while current.next is not None:
        current = current.next

    # اتصال گره جدید به انتهای لیست
    current.next = new_node

    return head


def print_list(head):
    current = head

    while current is not None:
        print(current.data)
        current = current.next


def main():
    try:
        n = int(input())

        if n < 0:
            print("invalid input")
            return

        linked_list = SinglyLinkedList()

        for _ in range(n):
            try:
                data = int(input())
                linked_list.head = insertNodeAtTail(
                    linked_list.head,
                    data
                )

            except ValueError:
                print("invalid input")
                return

        print_list(linked_list.head)

    except ValueError:
        print("invalid input")


if __name__ == "__main__":
    main()