class DynamicStack:
    def __init__(self):
        self.initial_capacity = 4
        self._capacity = 4
        self._size = 0
        self.data = [None] * self._capacity

    def _resize(self, new_capacity):
        new_data = [None] * new_capacity

        for i in range(self._size):
            new_data[i] = self.data[i]

        self.data = new_data
        self._capacity = new_capacity

    def push(self, value):
        if self._size == self._capacity:
            self._resize(self._capacity * 2)

        self.data[self._size] = value
        self._size += 1

    def pop(self):
        if self._size == 0:
            return None

        self._size -= 1
        value = self.data[self._size]

        self.data[self._size] = None

        if (
            self._capacity > self.initial_capacity
            and self._size * 4 <= self._capacity
        ):
            new_capacity = self._capacity // 2

            if new_capacity < self.initial_capacity:
                new_capacity = self.initial_capacity

            self._resize(new_capacity)

        return value

    def top(self):
        if self._size == 0:
            return None

        return self.data[self._size - 1]

    def size(self):
        return self._size

    def capacity(self):
        return self._capacity

    def show(self):
        result = []

        for i in range(self._size):
            result.append(self.data[i])

        return result


def main():
    try:
        q = int(input().strip())

        if q <= 0:
            print("invalid input")
            return

        stack = DynamicStack()

        for _ in range(q):
            parts = input().split()

            if len(parts) == 0:
                print("invalid input")
                return

            command = parts[0]

            if command == "push":
                if len(parts) != 2:
                    print("invalid input")
                    return

                value = int(parts[1])
                stack.push(value)

            elif command == "pop":
                if len(parts) != 1:
                    print("invalid input")
                    return

                result = stack.pop()

                if result is None:
                    print("None")
                else:
                    print(result)

            elif command == "top":
                if len(parts) != 1:
                    print("invalid input")
                    return

                result = stack.top()

                if result is None:
                    print("None")
                else:
                    print(result)

            elif command == "size":
                if len(parts) != 1:
                    print("invalid input")
                    return

                print(stack.size())

            elif command == "capacity":
                if len(parts) != 1:
                    print("invalid input")
                    return

                print(stack.capacity())

            elif command == "show":
                if len(parts) != 1:
                    print("invalid input")
                    return

                values = stack.show()

                if len(values) == 0:
                    print("empty")
                else:
                    print(" ".join(map(str, values)))

            else:
                print("invalid input")
                return

    except (ValueError, EOFError):
        print("invalid input")


if __name__ == "__main__":
    main()