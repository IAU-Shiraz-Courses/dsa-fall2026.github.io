class ListNode:
    def __init__(self, data):
        self.data = data
        self.next = None


def reverseKGroup(head, k):

    # یک گره کمکی قبل از head ایجاد می‌کنیم
    dummy = ListNode(0)
    dummy.next = head

    group_prev = dummy

    while True:

        # بررسی می‌کنیم آیا حداقل k گره باقی مانده است یا خیر
        kth = group_prev

        for _ in range(k):
            kth = kth.next

            if kth is None:
                return dummy.next

        # اولین گره بعد از گروه فعلی
        group_next = kth.next

        # معکوس کردن k گره
        prev = group_next
        current = group_prev.next

        while current != group_next:
            temp = current.next
            current.next = prev
            prev = current
            current = temp

        # اولین گره گروه قبل از معکوس شدن
        # بعد از معکوس شدن به انتهای گروه تبدیل می‌شود
        old_group_start = group_prev.next

        # اتصال گروه قبلی به ابتدای گروه معکوس‌شده
        group_prev.next = kth

        # آماده شدن برای گروه بعدی
        group_prev = old_group_start


def create_linked_list(values):
    if not values:
        return None

    head = ListNode(values[0])
    current = head

    for value in values[1:]:
        current.next = ListNode(value)
        current = current.next

    return head


def print_linked_list(head):
    current = head
    result = []

    while current is not None:
        result.append(str(current.data))
        current = current.next

    print(" ".join(result))


def main():
    try:
        n = int(input().strip())

        if n <= 0:
            print("invalid input")
            return

        values = list(map(int, input().split()))

        if len(values) != n:
            print("invalid input")
            return

        k = int(input().strip())

        if k <= 0 or k > n:
            print("invalid input")
            return

        head = create_linked_list(values)

        head = reverseKGroup(head, k)

        print_linked_list(head)

    except ValueError:
        print("invalid input")


if __name__ == "__main__":
    main()