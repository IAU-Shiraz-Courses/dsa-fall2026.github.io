class SimpleQueue:
    def __init__(self):
        self.data = []
        self.head = 0

    def is_empty(self):
        return self.head >= len(self.data)

    def enqueue(self, x):
        self.data.append(x)

    def dequeue(self):
        if self.is_empty():
            return None
        x = self.data[self.head]
        self.head += 1

        if self.head > 1000 and self.head * 2 > len(self.data):
            self.data = self.data[self.head :]
            self.head = 0

        return x

    def snapshot(self):
        return [] if self.is_empty() else self.data[self.head :]


def format_list(lst):
    return "[" + ", ".join(lst) + "]"


def main():
    q = SimpleQueue()

    while True:
        try:
            line = input().strip()
        except EOFError:
            break

        if not line:
            continue

        parts = line.split()
        cmd = parts[0].upper()

        if cmd == "ENQUEUE":
            if len(parts) != 2:
                continue
            q.enqueue(parts[1])

        elif cmd == "DEQUEUE":
            if len(parts) != 1:
                continue
            x = q.dequeue()
            if x is None:
                print("Empty queue")
            else:
                print(x)

        elif cmd == "DISPLAY":
            if len(parts) != 1:
                continue
            print(format_list(q.snapshot()))

        elif cmd == "EXIT":
            break

        else:
            continue


if __name__ == "__main__":
    main()
