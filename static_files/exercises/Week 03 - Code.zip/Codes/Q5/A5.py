class SimpleQueue:
    def __init__(self):
        self.data = []
        self.head = 0  # index of front

    def is_empty(self):
        return self.head >= len(self.data)

    def size(self):
        return len(self.data) - self.head

    def enqueue(self, x):
        self.data.append(x)

    def dequeue(self):
        if self.is_empty():
            return None
        x = self.data[self.head]
        self.head += 1

        if self.head > 1000 and self.head * 2 > len(self.data):
            self.data = self.data[self.head :]
            self.head = 0

        return x

    def front(self):
        if self.is_empty():
            return None
        return self.data[self.head]

    def snapshot(self):
        if self.is_empty():
            return []
        return self.data[self.head :]


class SimpleStack:
    def __init__(self):
        self.data = []

    def is_empty(self):
        return len(self.data) == 0

    def push(self, x):
        self.data.append(x)

    def pop(self):
        if self.is_empty():
            return None
        return self.data.pop()


def format_list(lst):
    return "[" + ", ".join(lst) + "]"


def main():
    q = SimpleQueue()
    s = SimpleStack()

    while True:
        try:
            line = input().strip()
        except EOFError:
            break

        if not line:
            print("Invalid input")
            continue

        parts = line.split()
        cmd = parts[0].upper()

        if cmd == "ARRIVE":
            if len(parts) != 2:
                print("Invalid input")
                continue
            x = parts[1]
            q.enqueue(x)

        elif cmd == "PASS":
            if len(parts) != 1:
                print("Invalid input")
                continue
            x = q.dequeue()
            if x is None:
                print("Empty queue")
            else:
                print(x)

        elif cmd == "EMERGENCY":

            if len(parts) != 1:
                print("Invalid input")
                continue

            if q.size() >= 2:
                first = q.dequeue()
                s.push(first)

                _second = q.dequeue()  

                saved = s.pop() 

                remaining = q.snapshot()
                q = SimpleQueue()
                q.enqueue(saved)
                for item in remaining:
                    q.enqueue(item)

        elif cmd == "DISPLAY":
            if len(parts) != 1:
                print("Invalid input")
                continue
            print(format_list(q.snapshot()))

        elif cmd == "EXIT":
            break

        else:
            print("Invalid input")


if __name__ == "__main__":
    main()
