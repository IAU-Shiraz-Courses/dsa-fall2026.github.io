class CircularDeque:
    def __init__(self, init_capacity=8):
        self.cap = max(2, init_capacity)
        self.arr = [None] * self.cap
        self.head = 0  
        self.size = 0

    def _idx(self, k):
        return (self.head + k) % self.cap

    def _resize(self, new_cap):
        new_arr = [None] * new_cap
        for i in range(self.size):
            new_arr[i] = self.arr[self._idx(i)]
        self.arr = new_arr
        self.cap = new_cap
        self.head = 0

    def is_empty(self):
        return self.size == 0

    def push_front(self, x):
        if self.size == self.cap:
            self._resize(self.cap * 2)
        self.head = (self.head - 1) % self.cap
        self.arr[self.head] = x
        self.size += 1

    def push_back(self, x):
        if self.size == self.cap:
            self._resize(self.cap * 2)
        tail_idx = self._idx(self.size)
        self.arr[tail_idx] = x
        self.size += 1

    def pop_front(self):
        if self.is_empty():
            return None
        x = self.arr[self.head]
        self.arr[self.head] = None
        self.head = (self.head + 1) % self.cap
        self.size -= 1

        # کوچک‌سازی اختیاری برای جلوگیری از مصرف حافظه زیاد
        if self.cap > 8 and self.size * 4 <= self.cap:
            self._resize(self.cap // 2)

        return x

    def to_list(self):
        return [self.arr[self._idx(i)] for i in range(self.size)]


def format_list(lst):
    return "[" + ", ".join(lst) + "]"


def main():
    dq = CircularDeque()

    while True:
        try:
            line = input().strip()
        except EOFError:
            break

        if not line:
            print("Invalid input")
            continue

        parts = line.split()
        cmd = parts[0].upper()

        if cmd == "ARRIVE_NORMAL":
            if len(parts) != 2:
                print("Invalid input")
                continue
            name = parts[1]
            dq.push_back(name)

        elif cmd == "ARRIVE_URGENT":
            if len(parts) != 2:
                print("Invalid input")
                continue
            name = parts[1]
            dq.push_front(name)

        elif cmd == "SERVE":
            if len(parts) != 1:
                print("Invalid input")
                continue
            x = dq.pop_front()
            if x is None:
                print("No patient")
            else:
                print(x)

        elif cmd == "DISPLAY":
            if len(parts) != 1:
                print("Invalid input")
                continue
            print(format_list(dq.to_list()))

        elif cmd == "EXIT":
            break

        else:
            print("Invalid input")


if __name__ == "__main__":
    main()
