import sys
import re


# ------------------------------------------
# - ممکن است ورودی چندخطی باشد
# - با regex فقط عددها را استخراج می‌کنیم
# فرمت مسئله:
# n
# a1 a2 ... an
# x
# ------------------------------------------
def read_input():
    text = sys.stdin.read()
    nums = list(map(int, re.findall(r"-?\d+", text)))
    if len(nums) < 2:
        return None

    n = nums[0]
    arr = nums[1 : 1 + n]
    x = nums[1 + n]
    return n, arr, x


# ------------------------------------------
# lower_bound:
# اولین اندیسی که arr[idx] >= x
# اگر همه عناصر < x باشند، خروجی n می‌شود.
# ------------------------------------------
def lower_bound(arr, x):
    lo, hi = 0, len(arr)  # hi = n (کران بالا خارج از آرایه)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] >= x:
            hi = mid  # جواب می‌تواند mid یا چپ‌تر باشد
        else:
            lo = mid + 1  # باید به راست برویم
    return lo


# ------------------------------------------
# upper_bound:
# اولین اندیسی که arr[idx] > x
# اگر همه عناصر <= x باشند، خروجی n می‌شود.
# ------------------------------------------
def upper_bound(arr, x):
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] > x:
            hi = mid  # جواب می‌تواند mid یا چپ‌تر باشد
        else:
            lo = mid + 1  # باید به راست برویم
    return lo


def main():
    data = read_input()
    if data is None:
        return

    n, arr, x = data

    # پیدا کردن اولین وقوع x:
    first = lower_bound(arr, x)

    # اگر first خارج از محدوده باشد یا مقدارش x نباشد => x وجود ندارد
    if first == n or arr[first] != x:
        print("-1 -1")
        return

    # آخرین وقوع x برابر است با upper_bound(x) - 1
    last = upper_bound(arr, x) - 1

    print(first, last)


if __name__ == "__main__":
    main()
