import sys


# -----------------------------
# Disjoint Set Union (Union-Find) - نسخه پایه
# - بدون Path Compression
# - بدون Union by Rank
# -----------------------------
class DisjointSet:
    def __init__(self):
        # parent[x] = پدر x در درخت نمایندگی مجموعه
        # اگر x نماینده باشد، parent[x] = x
        self.parent = {}

    def make_set(self, x):
        # اگر x را قبلاً ندیده‌ایم، یک مجموعه جدید برایش بساز
        if x not in self.parent:
            self.parent[x] = x

    def find(self, x):
        """
        پیدا کردن نماینده (Representative) مجموعه‌ی شامل x
        نسخه پایه: فقط با بالا رفتن از parent ها
        (بدون Path Compression)
        """
        # فرض: x حتماً make_set شده است
        while self.parent[x] != x:
            x = self.parent[x]
        return x

    def union(self, a, b):
        """
        ادغام دو مجموعه:
        نماینده‌ی a و b را پیدا می‌کنیم.
        اگر متفاوت باشند، یکی را زیر دیگری می‌بریم.
        (نسخه پایه، بدون Rank)
        """
        ra = self.find(a)
        rb = self.find(b)

        if ra != rb:
            # نماینده rb را زیر نماینده ra قرار می‌دهیم
            self.parent[rb] = ra


def main():
    dsu = DisjointSet()

    # خواندن خط به خط ورودی
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        parts = line.split()
        cmd = parts[0].upper()

        if cmd == "EXIT":
            break

        elif cmd == "CONNECT":
            # CONNECT x y
            x, y = parts[1], parts[2]

            # هر کاربر جدید را ابتدا make_set می‌کنیم
            dsu.make_set(x)
            dsu.make_set(y)

            # سپس اتصال (Union)
            dsu.union(x, y)

        elif cmd == "CHECK":
            # CHECK x y
            x, y = parts[1], parts[2]

            # اگر قبلاً دیده نشده باشند، باز هم باید مجموعه مستقل بسازیم
            dsu.make_set(x)
            dsu.make_set(y)

            # اگر نماینده‌ها برابر باشند یعنی در یک مجموعه‌اند
            if dsu.find(x) == dsu.find(y):
                print("YES")
            else:
                print("NO")

        else:
            continue


if __name__ == "__main__":
    main()
