import sys
import re


# ----------------------------------------------------
# ممکن است داده‌ها در چند خط یا یک خط باشند.
# فرمت مسئله:
# n q
# a1 a2 ... an   (آرایه مرتب)
# سپس q خط: Li Ri
# ----------------------------------------------------
def read_input():
    text = sys.stdin.read()
    nums = list(map(int, re.findall(r"-?\d+", text)))
    if len(nums) < 2:
        return None

    n, q = nums[0], nums[1]
    arr = nums[2 : 2 + n]

    # بعد از آرایه باید 2*q عدد دیگر برای Queryها باشد
    queries = []
    idx = 2 + n
    for _ in range(q):
        L = nums[idx]
        R = nums[idx + 1]
        queries.append((L, R))
        idx += 2

    return n, q, arr, queries


# ----------------------------------------------------
# lower_bound(arr, x):
# اولین اندیسی که arr[i] >= x
# اگر همه عناصر < x باشند، خروجی n است.
# ----------------------------------------------------
def lower_bound(arr, x):
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] >= x:
            hi = mid
        else:
            lo = mid + 1
    return lo


# ----------------------------------------------------
# upper_bound(arr, x):
# اولین اندیسی که arr[i] > x
# اگر همه عناصر <= x باشند، خروجی n است.
# ----------------------------------------------------
def upper_bound(arr, x):
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] > x:
            hi = mid
        else:
            lo = mid + 1
    return lo


def main():
    data = read_input()
    if data is None:
        return

    n, q, arr, queries = data

    # برای هر Query:
    # تعداد عناصر در بازه [L, R] =
    # upper_bound(R) - lower_bound(L)
    out_lines = []
    for L, R in queries:
        left = lower_bound(arr, L)  # اولین >= L
        right = upper_bound(arr, R)  # اولین > R
        out_lines.append(str(right - left))

    print("\n".join(out_lines))


if __name__ == "__main__":
    main()
