import sys
import re


# ------------------------------------------------------------
# n
# a1 a2 ... an
# k   (1-based)
# ------------------------------------------------------------
def read_input():
    text = sys.stdin.read()
    nums = list(map(int, re.findall(r"-?\d+", text)))
    if len(nums) < 2:
        return None
    n = nums[0]
    arr = nums[1 : 1 + n]
    k = nums[1 + n]  # 1-based
    return arr, k


# ------------------------------------------------------------
# median_of_medians_pivot:
# یک pivot خوب می‌سازد که تضمین بدترین حالت O(n) بدهد.
# ایده:
# 1) آرایه را به گروه‌های 5تایی تقسیم کن
# 2) median هر گروه را پیدا کن
# 3) میانه‌ی medianها را به صورت بازگشتی پیدا کن => pivot
# ------------------------------------------------------------
def median_of_medians_pivot(a):
    n = len(a)
    if n <= 5:
        # برای اندازه کوچک، مرتب می‌کنیم و وسط را pivot می‌گیریم
        return sorted(a)[n // 2]

    medians = []
    # گروه‌های 5تایی
    for i in range(0, n, 5):
        group = a[i : i + 5]
        group.sort()
        medians.append(group[len(group) // 2])  # median گروه

    # pivot = میانه‌ی medians
    return select_kth(medians, (len(medians) + 1) // 2)


# ------------------------------------------------------------
# select_kth(a, k):
# k-اُمین کوچک‌ترین عنصر (k از 1 شروع می‌شود)
# با Median of Medians => تضمین O(n) در بدترین حالت
# ------------------------------------------------------------
def select_kth(a, k):
    # حالت پایه
    if len(a) == 1:
        return a[0]

    pivot = median_of_medians_pivot(a)

    # تقسیم آرایه به سه بخش نسبت به pivot
    lows = []
    highs = []
    pivots = []  # (در این مسئله عناصر متمایزند، ولی برای حالت عمومی نگه می‌داریم)
    for x in a:
        if x < pivot:
            lows.append(x)
        elif x > pivot:
            highs.append(x)
        else:
            pivots.append(x)

    # تصمیم‌گیری اینکه k در کدام بخش است
    if k <= len(lows):
        return select_kth(lows, k)
    elif k <= len(lows) + len(pivots):
        return pivot
    else:
        # k وارد بخش highs می‌شود؛ باید k را نسبت به شروع highs تنظیم کنیم
        new_k = k - len(lows) - len(pivots)
        return select_kth(highs, new_k)


def main():
    data = read_input()
    if data is None:
        return
    arr, k = data
    ans = select_kth(arr, k)
    print(ans)


if __name__ == "__main__":
    main()
