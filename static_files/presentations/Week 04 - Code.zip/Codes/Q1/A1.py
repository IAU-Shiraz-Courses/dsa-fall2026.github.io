class Node:
    def __init__(self, id, tier):
        self.id = id
        self.tier = tier
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, id, tier):
        self.root = self._insert(self.root, id, tier)

    def _insert(self, node, id, tier):
        if node is None:
            return Node(id, tier)
        if id == node.id:
            return node
        elif id < node.id:
            node.left = self._insert(node.left, id, tier)
        else:
            node.right = self._insert(node.right, id, tier)
        return node

    def find(self, id):
        result = self._find(self.root, id)
        if result:
            print(result.tier)
        else:
            print("NOT FOUND")

    def _find(self, node, id):
        if node is None:
            return None
        if id == node.id:
            return node
        elif id < node.id:
            return self._find(node.left, id)
        else:
            return self._find(node.right, id)

    def inorder(self):
        result = []
        self._inorder(self.root, result)
        if result:
            print(" ".join(map(str, result)))
        # اگر خالی بود، چاپ نمی‌کند (همانطور که در سوال نوشته شده)

    def _inorder(self, node, result):
        if node:
            self._inorder(node.left, result)
            result.append(node.id)
            self._inorder(node.right, result)


# اجرای برنامه
bst = BST()

n_initial_nodes = int(input())
for _ in range(n_initial_nodes):
    parts = input().split()
    id_val = int(parts[0])
    tier_val = int(parts[1])
    bst.insert(id_val, tier_val)

n_commands = int(input())
for _ in range(n_commands):
    cmd_line = input().split()
    if cmd_line[0] == "INORDER":
        bst.inorder()
    elif cmd_line[0] == "FIND":
        id_to_find = int(cmd_line[1])
        bst.find(id_to_find)
    elif cmd_line[0] == "INSERT":
        id_to_insert = int(cmd_line[1])
        tier_to_insert = int(cmd_line[2])
        bst.insert(id_to_insert, tier_to_insert)
## TST