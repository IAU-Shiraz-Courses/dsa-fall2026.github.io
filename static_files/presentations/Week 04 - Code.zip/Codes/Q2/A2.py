# تعریف کلاس گره درخت
class Node:
    def __init__(self, value):
        self.value = value      # مقدار گره
        self.left = None        # فرزند چپ
        self.right = None       # فرزند راست


# تابع درج در BST
def insert(root, value):
    # اگر درخت خالی باشد گره جدید ساخته می‌شود
    if root is None:
        return Node(value)

    # اگر مقدار کوچک‌تر باشد به سمت چپ می‌رویم
    if value < root.value:
        root.left = insert(root.left, value)

    # اگر مقدار بزرگ‌تر باشد به سمت راست می‌رویم
    elif value > root.value:
        root.right = insert(root.right, value)

    # اگر برابر باشد هیچ کاری نمی‌کنیم (عدم درج تکراری)
    return root


# تابع جستجو در BST
def search(root, value):
    # اگر به گره خالی رسیدیم یعنی وجود ندارد
    if root is None:
        return False

    # اگر مقدار پیدا شد
    if root.value == value:
        return True

    # اگر مقدار کوچک‌تر باشد در زیر درخت چپ جستجو می‌کنیم
    if value < root.value:
        return search(root.left, value)

    # در غیر این صورت در زیر درخت راست
    return search(root.right, value)


# پیمایش inorder برای چاپ مرتب
def inorder(root, result):
    if root is None:
        return

    inorder(root.left, result)
    result.append(root.value)
    inorder(root.right, result)


# تعداد عملیات‌ها
n = int(input())

# ریشه درخت
root = None

for _ in range(n):
    data = list(map(int, input().split()))
    op = data[0]

    # عملیات درج
    if op == 1:
        value = data[1]
        root = insert(root, value)

    # عملیات جستجو
    elif op == 2:
        value = data[1]
        if search(root, value):
            print("YES")
        else:
            print("NO")

    # عملیات چاپ مرتب
    elif op == 3:
        result = []
        inorder(root, result)
        print(*result)
