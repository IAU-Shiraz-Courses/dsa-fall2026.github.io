# تابع مقایسه دو گره
# برمی‌گرداند آیا a باید بالاتر از b قرار بگیرد یا نه
def higher_priority(a, b):
    like_a, id_a = a
    like_b, id_b = b

    if like_a != like_b:
        return like_a > like_b
    else:
        return id_a < id_b



# بالا بردن گره در heap (heapify up)
def heapify_up(heap, index):
    while index > 0:
        parent = (index - 1) // 2

        if higher_priority(heap[index], heap[parent]):
            heap[index], heap[parent] = heap[parent], heap[index]
            index = parent
        else:
            break



# پایین بردن گره در heap (heapify down)
def heapify_down(heap, index):
    n = len(heap)

    while True:
        left = 2 * index + 1
        right = 2 * index + 2
        largest = index

        if left < n and higher_priority(heap[left], heap[largest]):
            largest = left

        if right < n and higher_priority(heap[right], heap[largest]):
            largest = right

        if largest != index:
            heap[index], heap[largest] = heap[largest], heap[index]
            index = largest
        else:
            break



# اضافه کردن عنصر به heap
def push(heap, value):
    heap.append(value)
    heapify_up(heap, len(heap) - 1)



# حذف بیشترین عنصر
def pop(heap):
    if not heap:
        return None

    root = heap[0]
    last = heap.pop()

    if heap:
        heap[0] = last
        heapify_down(heap, 0)

    return root



# خواندن تعداد عملیات
n = int(input())

# heap اصلی
heap = []

# دیکشنری برای نگهداری مقدار واقعی لایک‌ها
likes = {}

for _ in range(n):

    data = list(map(int, input().split()))
    op = data[0]

    # عملیات افزودن پست
    if op == 1:
        post_id = data[1]
        like_count = data[2]

        if post_id not in likes:
            likes[post_id] = like_count
            push(heap, (like_count, post_id))

    # عملیات افزایش لایک
    elif op == 2:
        post_id = data[1]
        x = data[2]

        if post_id in likes:
            likes[post_id] += x
            push(heap, (likes[post_id], post_id))

    # عملیات گرفتن k پست برتر
    elif op == 3:
        k = data[1]

        temp = []
        result = []

        while heap and len(result) < k:

            top = pop(heap)
            like_val, post_id = top

            # بررسی معتبر بودن مقدار
            if post_id in likes and likes[post_id] == like_val:
                result.append(post_id)
                temp.append(top)

        # برگرداندن عناصر معتبر به heap
        for item in temp:
            push(heap, item)

        print(*result)
