def counting_sort_by_digit(arr, exp, base, trace=False):
    """
    مرتب‌سازی شمارشی پایدار برای یک موقعیت رقمی خاص
    با قابلیت ردیابی مراحل و ساخت باکت‌ها
    """
    n = len(arr)
    output = [0] * n
    count = [0] * base
    buckets = {}
    
    # ساخت باکت‌ها و شمارش
    for num in arr:
        digit = (num // exp) % base
        count[digit] += 1
        if digit not in buckets:
            buckets[digit] = []
        buckets[digit].append(num)
    
    # محاسبه مقادیر تجمعی
    cumulative = count.copy()
    for i in range(1, base):
        cumulative[i] += cumulative[i - 1]
    
    # ساخت آرایه خروجی با حفظ پایداری
    for i in range(n - 1, -1, -1):
        digit = (arr[i] // exp) % base
        cumulative[digit] -= 1
        output[cumulative[digit]] = arr[i]
    
    if trace:
        return output, count, buckets
    return output


def radix_sort_with_base_optimization(arr):
    """
    الگوریتم Radix Sort با انتخاب هوشمند مبنا
    بر اساس تعداد ارقام و اندازه آرایه
    """
    if not arr:
        return arr, []
    
    n = len(arr)
    max_num = max(arr)
    
    # محاسبه تعداد ارقام
    num_digits = len(str(max_num))
    
    # انتخاب مبنای بهینه بر اساس تعداد ارقام
    if num_digits <= 4:
        base = 10  # برای اعداد کوچک
    elif num_digits <= 8:
        base = 100  # برای اعداد متوسط (دو رقم در هر پاس)
    elif num_digits <= 12:
        base = 1000  # برای اعداد بزرگ (سه رقم در هر پاس)
    else:
        base = 10000  # برای اعداد خیلی بزرگ (چهار رقم در هر پاس)
    
    result = arr.copy()
    trace_log = []
    
    # محاسبه تعداد پاس‌ها
    exp = 1
    pass_count = 0
    
    while max_num // exp > 0:
        pass_count += 1
        
        # اجرای counting sort با ردیابی
        sorted_arr, count_arr, buckets = counting_sort_by_digit(
            result, exp, base, trace=True
        )
        
        # ذخیره اطلاعات مرحله
        trace_log.append({
            'pass': pass_count,
            'exp': exp,
            'base': base,
            'buckets': buckets,
            'count_array': count_arr,
            'result': sorted_arr.copy()
        })
        
        result = sorted_arr
        exp *= base
    
    return result, trace_log


def analyze_performance(arr):
    """
    تحلیل عملکرد برای مبناهای مختلف
    """
    max_num = max(arr) if arr else 0
    num_digits = len(str(max_num))
    n = len(arr)
    
    analysis = {}
    
    for base in [10, 100, 1000, 10000]:
        num_passes = 0
        temp = max_num
        
        while temp > 0:
            temp //= base
            num_passes += 1
        
        memory_per_pass = base * 8  # bytes for 64-bit integers
        total_memory = memory_per_pass + n * 8  # counting array + output array
        
        analysis[base] = {
            'passes': num_passes,
            'memory_per_pass': memory_per_pass,
            'total_memory': total_memory,
            'comparisons': 0,  # Radix sort doesn't use comparisons
            'time_complexity': f"O({num_passes} * (n + {base}))"
        }
    
    return analysis


def main():
    """
    برنامه اصلی با پردازش ورودی و خروجی
    """
    # دریافت ورودی
    numbers = list(map(int, input().split()))
    
    # اجرای الگوریتم با بهینه‌سازی خودکار
    sorted_result, trace = radix_sort_with_base_optimization(numbers)
    
    # محاسبه آمار
    if trace:
        base_used = trace[0]['base']
        num_passes = len(trace)
        
        # پیدا کردن میانه بعد از مرحله دوم (اگر وجود داشته باشد)
        median_after_pass2 = None
        if num_passes >= 2:
            arr_after_pass2 = trace[1]['result']
            mid = len(arr_after_pass2) // 2
            if len(arr_after_pass2) % 2 == 0:
                median_after_pass2 = (arr_after_pass2[mid-1] + arr_after_pass2[mid]) // 2
            else:
                median_after_pass2 = arr_after_pass2[mid]
    
    # تحلیل عملکرد
    performance = analyze_performance(numbers)
    
    # خروجی اصلی - لیست مرتب شده
    print(*sorted_result)
    

    if len(numbers) <= 20:  
        print(f"# Base: {base_used}, Passes: {num_passes}")
        if median_after_pass2:
            print(f"# Median after pass 2: {median_after_pass2}")
        

if __name__ == "__main__":
    main()