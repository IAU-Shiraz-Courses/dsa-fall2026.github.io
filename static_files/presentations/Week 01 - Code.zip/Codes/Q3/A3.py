def madagascar_escape_sort(priorities):
    if not priorities:
        return priorities

    # ۱. پیدا کردن بازه برای مدیریت اعداد منفی (Offset)
    min_val = min(priorities)
    max_val = max(priorities)
    range_of_elements = max_val - min_val + 1
    
    # ۲. ایجاد آرایه‌های مورد نیاز
    count_arr = [0] * range_of_elements
    output_arr = [0] * len(priorities)

    # ۳. شمارش تکرارها با استفاده از Offset
    for x in priorities:
        count_arr[x - min_val] += 1

    # ۴. محاسبه فرکانس تجمعی برای تعیین جایگاه‌ها
    for i in range(1, len(count_arr)):
        count_arr[i] += count_arr[i - 1]

    # ۵. ساخت خروجی به صورت پایدار (از انتها به ابتدا)
    for i in range(len(priorities) - 1, -1, -1):
        current_val = priorities[i]
        position = count_arr[current_val - min_val] - 1
        output_arr[position] = current_val
        count_arr[current_val - min_val] -= 1

    return output_arr

if __name__ == "__main__":
    try:
        
        priorities = list(map(int, input().split()))
        
        if not priorities:
            print("لیست خالی است!")
        else:
            sorted_priorities = madagascar_escape_sort(priorities)
            print(sorted_priorities)
            
    except ValueError:
        print("خطا! لطفاً فقط عدد صحیح وارد کنید.")