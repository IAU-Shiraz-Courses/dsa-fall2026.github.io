def gravity_falls_selection(pages):
    n = len(pages)
    
    # پیمایش مرز بخش مرتب‌شده و نامرتب
    for i in range(n):
        # فرض می‌کنیم اولین عنصر بخش نامرتب (i)، کمترین است
        min_idx = i
        
        # جستجو در بخش نامرتب برای پیدا کردن کمترینِ واقعی
        for j in range(i + 1, n):
            if pages[j] < pages[min_idx]:
                min_idx = j
        
        # جابجایی عنصر پیدا شده با اولین عنصر بخش نامرتب
        # نکته: حتی اگر min_idx تغییر نکرده باشد، جابجایی با خودش بی‌خطر است
        pages[i], pages[min_idx] = pages[min_idx], pages[i]
        


    return pages

if __name__ == "__main__":
    try:
        journal_pages = list(map(int, input().split()))
        
        if not journal_pages:
            print("هیچ صفحه‌ای پیدا نشد! بیل سایفر برنده شد!")
        else:
            sorted_pages = gravity_falls_selection(journal_pages)
            print(sorted_pages)
            
    except ValueError:
        print("خطا! اعداد جادویی باید عدد صحیح باشند.")