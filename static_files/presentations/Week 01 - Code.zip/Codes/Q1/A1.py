def monster_door_sort(doors):
    n = len(doors)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if doors[j] > doors[j + 1]:
                # جابجایی درهای مجاور
                doors[j], doors[j + 1] = doors[j + 1], doors[j]
                swapped = True
        
        # بهینه‌سازی: اگر جابجایی رخ نداد، لیست مرتب است
        if not swapped:
            break
    return doors

if __name__ == "__main__":
    try:
        
        door_heights = list(map(int, input().split()))
        
        if not door_heights:
            print("انبار خالی است!")
        else:
            sorted_doors = monster_door_sort(door_heights)
            print(sorted_doors)
    except ValueError:
        print("خطا! فقط اعداد صحیح وارد کنید.")