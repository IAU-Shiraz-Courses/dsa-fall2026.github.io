def get_digit_sum(num_str):
    """
    محاسبه مجموع ارقام یک رشته عددی
    مثال: "521" -> 5 + 2 + 1 = 8
    """
    total = 0
    for char in num_str:
        if char.isdigit():
            total += int(char)
    return total

def fraud_detection_sort(numbers):
    """
    الگوریتم مرتب‌سازی Bucket Sort برای تشخیص کلاهبرداری
    ورودی: لیست رشته‌های عددی
    خروجی: لیست مرتب شده بر اساس قوانین بانک
    """
    
    # 1. ایجاد 10 سطل خالی
    buckets = [[] for _ in range(10)]
    
    # 2. توزیع اعداد در سطل‌ها
    for num_str in numbers:
        d_sum = get_digit_sum(num_str)
        
        # قانون سطل‌بندی
        if d_sum % 2 == 0:
            # زوج: بر اساس رقم اول
            bucket_index = int(num_str[0])
        else:
            # فرد: بر اساس رقم آخر
            bucket_index = int(num_str[-1])
        
        buckets[bucket_index].append(num_str)
    
    # 3. مرتب‌سازی و جمع‌آوری
    sorted_result = []
    
    for i in range(10):
        if not buckets[i]:
            continue
        
        if i <= 4:
            # سطل‌های کم‌خطر: صعودی
            buckets[i].sort()
        else:
            # سطل‌های پرخطر: نزولی
            buckets[i].sort(reverse=True)
        
        sorted_result.extend(buckets[i])
    
    return sorted_result

# بخش اصلی
if __name__ == "__main__":
    try:
        user_input = input().split()
        
        # فراخوانی تابع
        result = fraud_detection_sort(user_input)
        
        # چاپ خروجی
        print(' '.join(result))
        
    except Exception as e:
        print(f"Error: {e}")